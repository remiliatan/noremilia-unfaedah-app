<?php

	include "koneksi.php";
	class usr{}

	$id_komentar = $_POST["id_komentar"];
	$komentar = $_POST["komentar"];

	$query = "UPDATE komentar set komentar='$komentar' where id_komentar='$id_komentar';";
	$sql = mysqli_query($conn, $query);

	if($sql){
		$response = new usr();
		$response->success = 1;
		$response->message = "Komentar Diubah";
		die(json_encode($response));
	}else{
		$response = new usr();
		$response->success = 0;
		$response->message = "Gagal mengubah";
		die(json_encode($response));
	}

	mysqli_close($conn);

?>