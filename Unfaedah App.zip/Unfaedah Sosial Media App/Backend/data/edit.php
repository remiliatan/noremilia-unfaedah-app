<?php

	include "koneksi.php";
	class usr{}

	$id = $_POST["id"];
	$caption =$_POST["caption"];

	$query2 = "UPDATE data set caption='$caption' where id='$id';";
	$sql2 = mysqli_query($conn, $query2);

	if ($sql2){
		$response = new usr();
		$response->success = 1;
		$response->message = "Sukses";
		die (json_encode($response));
	}else{
		$response = new usr();
		$response->success = 0;
		$response->message = "Gagal Mengedit";
		die(json_encode($response));
	}

	mysqli_close($conn)

?>