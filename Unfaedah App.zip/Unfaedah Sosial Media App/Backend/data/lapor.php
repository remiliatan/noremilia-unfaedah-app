<?php

	include "koneksi.php";
	class usr{}

	$alasan = $_POST["alasan"];
	$id_akun = $_POST["id_akun"];
	$id = $_POST["id"];
	$keterangan = $_POST["keterangan"];

	$query = "INSERT INTO laporan (id_laporan, id, id_akun, alasan, keterangan) VALUES (NULL, '".$id."', '".$id_akun."' , '".$alasan."','".$keterangan."')";
	$sql = mysqli_query($conn, $query);

	if($sql){
		$response = new usr();
		$response->success = 1;
		$response->message = "Kiriman Dilaporkan";
		die(json_encode($response));
	}else{
		$response = new usr();
		$response->success = 0;
		$response->message = "Gagal";
		die(json_encode($response));
	}

	mysqli_close($conn);
?>