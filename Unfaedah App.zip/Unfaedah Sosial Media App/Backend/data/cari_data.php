<?php 
	include_once "koneksi.php";

	$nama = $_POST['keyword'];

	$query = mysqli_query($conn, "SELECT * FROM akun WHERE nama_admin LIKE '%".$nama."%'");

	$num_rows = mysqli_num_rows($query);

	if ($num_rows > 0){
		$json = '{"value":1, "results": [';

		while ($row = mysqli_fetch_array($query)){
			$char ='"';

			$json .= '{
				"id_akun": "'.str_replace($char,'`',strip_tags($row['id_akun'])).'",
				"nama_admin": "'.str_replace($char,'`',strip_tags($row['nama_admin'])).'",
				"deskripsi": "'.str_replace($char,'`',strip_tags($row['deskripsi'])).'",
				"ikon": "'.str_replace($char,'`',strip_tags($row['ikon'])).'"
			},';
		}

		$json = substr($json,0,strlen($json)-1);

		$json .= ']}';

	} else {
		$json = '{"value":0, "message": "Data tidak ditemukan."}';
	}

	echo $json;

	mysqli_close($conn);
?>