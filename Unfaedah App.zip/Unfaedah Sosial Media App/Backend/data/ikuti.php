<?php

  include "koneksi.php";



 if (isset($_POST['ikuti'])) {
		$postid = $_POST['id_akun'];
		$id_akun = $_POST['id_pengikut'];
		$result = mysqli_query($conn, "SELECT * FROM akun WHERE id_akun='$postid';");
		$row = mysqli_fetch_array($result);
		$n = $row['pengikut'];

		mysqli_query($conn, "INSERT INTO pengikut (id_ikuti, id_akun, id_pengikut) VALUES (NULL, '".$postid."', '".$id_akun."')");
		mysqli_query($conn, "UPDATE akun SET pengikut='$n'+1 WHERE id_akun='$postid';");

		echo $n+1;
	}
	if (isset($_POST['tidak_ikuti'])) {
		$postid = $_POST['id_akun'];
		$id_akun = $_POST['id_pengikut'];
		$result = mysqli_query($conn, "SELECT * FROM akun WHERE id_akun='$postid';");
		$row = mysqli_fetch_array($result);
		$n = $row['pengikut'];

		mysqli_query($conn, "DELETE FROM pengikut WHERE id_akun='$postid' AND id_pengikut='$id_akun';");
		mysqli_query($conn, "UPDATE akun SET pengikut='$n'-1 WHERE id_akun='$postid'");
		
		echo $n-1;
	}


	 mysqli_close($conn);
?>