<?php

	include "koneksi.php";
	class usr{}

	$id = $_POST["id"];
	
	$foreign = "SET FOREIGN_KEY_CHECKS=0;";
	mysqli_query($conn, $foreign);

	$query = "DELETE FROM data where id='$id';";
	$sql = mysqli_query($conn, $query);
	
	$target = $_POST["gambar"];


    if(file_exists($target)){
	unlink($target);
	
    }
    
	if ($sql){
		$response = new usr();
		$response->success = 1;
		$response->message = "Sukses";
		die (json_encode($response));
	}else{
		$response = new usr();
		$response->success = 0;
		$response->message = "Gagal";
		die(json_encode($response));
	}

	mysqli_close($conn)

?>