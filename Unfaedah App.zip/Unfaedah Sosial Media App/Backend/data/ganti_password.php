<?php

	include "koneksi.php";
	class usr{}

	$id_akun = $_POST["id_akun"];
	$password =$_POST["password"];

	$query = "UPDATE akun set password='$password' where id_akun='$id_akun';";
	$sql = mysqli_query($conn, $query);

	if ($sql){
		$response = new usr();
		$response->success = 1;
		$response->message = "Sukses, login ulang dengan password baru";
		die (json_encode($response));
	}

	mysqli_close($conn)

?>