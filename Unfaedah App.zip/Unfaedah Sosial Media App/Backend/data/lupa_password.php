<?php

 include "koneksi.php";

 	class usr{}

 	$username = $_POST["username"];

 	$queryLihat = "SELECT * FROM akun WHERE username='$username';";
 	$sqLihat = mysqli_query($conn, $queryLihat);


 	$row = mysqli_fetch_array($sqLihat);

 	if(!empty($row)){
 		$response = new usr();
 		$response->success = 1;
 		$response->id_akun =$row['id_akun'];
 		$response->ikon =$row['ikon'];
 		$response->nama_admin =$row['nama_admin'];
 		$response->deskripsi =$row['deskripsi'];
 		$response->email =$row['email'];
 		die(json_encode($response));
 		
 		
 		}else { 
	 	$response = new usr();
	 	$response->success = 0;
	 	die(json_encode($response));
	 }

	

 		mysqli_close($conn);

 ?>