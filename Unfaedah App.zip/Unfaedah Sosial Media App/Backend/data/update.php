<?php
 include_once "koneksi.php";

class usr{}

	 $nama_admin = $_POST["nama_admin"];
	 $id_akun =$_POST["id_akun"];
	 $email = $_POST["email"];
	$deskripsi = $_POST["deskripsi"];	



	 if ((empty($nama_admin))) {
 		$response = new usr();
	 	$response->success = 0;
	 	$response->message = "Kolom Nama tidak boleh kosong";
	 	die(json_encode($response));
	 
	 } else if((empty($deskripsi))){
	 	$response = new usr();
	 	$response->success = 0;
	 	$response->message = "Kolom deskripsi tidak boleh kosong";
	 	die(json_encode($response));
	 } else if((empty($email))){
	 	$response = new usr();
	 	$response->success = 0;
	 	$response->message = "Kolom E-Mail tidak boleh kosong";
	 	die(json_encode($response));
	 }else {
 

		if ( isset($_POST["ikon"]) ) {


	 	$tanggal = date('dmYHis');
	$fotobaru = "gambar-".$tanggal;
		$random = random_word (20);
			$path = "ikon/".$id_akun.$fotobaru.".png";
			$actualpath ="http://192.168.43.171/meme/$path";
			 		$query = "UPDATE akun SET nama_admin = '$nama_admin', deskripsi = '$deskripsi', ikon = '$path', email='$email' WHERE id_akun = $id_akun;";
			 		
			 			$target = $_POST["gambar"];
                        if(file_exists($target)){
                    	unlink($target);
                     }
                     
	 		if (mysqli_query($conn, $query)){
	 			$ikon = $_POST["ikon"];
	 				file_put_contents($path,base64_decode($ikon));
		 			$response = new usr();
		 			$response->data = $query;
		 			$response->success = 1;
		 			$response->message = "Berhasil, login ulang untuk lanjut";
		 			die(json_encode($response));

		 	}
		} else {
			$query = "UPDATE akun SET email='$email', nama_admin = '$nama_admin', deskripsi = '$deskripsi' WHERE id_akun = $id_akun;";
	 		if (mysqli_query($conn, $query)){
		 			$response = new usr();
		 			$response->data = $query;
		 			$response->success = 1;
		 			$response->message = "Berhasil, login ulang untuk lanjut";
		 			die(json_encode($response));

		 	}
		}
	}
	
// fungsi random string pada gambar untuk menghindari nama file yang sama
	function random_word($id = 20){
		$pool = '1234567890abcdefghijkmnpqrstuvwxyz';
		
		$word = '';
		for ($i = 0; $i < $id; $i++){
			$word .= substr($pool, mt_rand(0, strlen($pool) -1), 1);
		}
		return $word; 
	}
	 mysqli_close($conn);

?>	