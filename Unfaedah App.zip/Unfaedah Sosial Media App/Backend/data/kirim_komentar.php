<?php
 include_once "koneksi.php";

class usr{}

	 $id_akun =$_POST["id_akun"];
	 $komentar = $_POST["komentar"];
	 $id = $_POST["id"];



	 if ((empty($komentar))) {
 		$response = new usr();
	 	$response->success = 0;
	 	$response->message = "Kolom komentar tidak boleh kosong";
	 	die(json_encode($response));
	 
	 }else {

		 	


		 		$query = mysqli_query($conn, "INSERT INTO komentar (id_komentar, id, id_akun, komentar) VALUES(NULL,'".$id."','".$id_akun."','".$komentar."')");

	 		if ($query){
		 			$response = new usr();
		 			$response->success = 1;
		 			$response->message = "Komentar terkirim";
		 			die(json_encode($response));

		 		}
		 		}
	
	 mysqli_close($conn);

?>	