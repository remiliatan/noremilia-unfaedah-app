<?php
 include_once "koneksi.php";

class usr{}

	 $username = $_POST["username"];
	 $password = $_POST["password"];
	 $confirm_password = $_POST["confirm_password"];
	 $profil = $_POST["profil"];
	 $info = $_POST["info"];
	 $email = $_POST["email"];
	 $nama_admin= $_POST["nama_admin"];



	 if ((empty($username))) {
 		$response = new usr();
	 	$response->success = 0;
	 	$response->message = "Kolom username tidak boleh kosong";
	 	die(json_encode($response));
	 } else if ((empty($email))) {
	 	$response = new usr();
	 	$response->success = 0;
	 	$response->message = "Kolom E-Mail tidak boleh kosong";
	 	die(json_encode($response));
	 } else if ((empty($password))) {
	 	$response = new usr();
	 	$response->success = 0;
	 	$response->message = "Kolom password tidak boleh kosong";
	 	die(json_encode($response));
	 } else if ((empty($confirm_password)) || $password != $confirm_password) {
	 	$response = new usr();
	 	$response->success = 0;
	 	$response->message = "Konfirmasi password tidak sama";
	 	die(json_encode($response));
	 } else if((empty($profil))){
	 	$response = new usr();
	 	$response->success = 0;
	 	$response->message = "Tolong tambahkan foto profil";
	 	die(json_encode($response));
	 }else if((empty($info))){
	 	$response = new usr();
	 	$response->success = 0;
	 	$response->message = "Tolong deskripsikan diri kamu";
	 	die(json_encode($response));
	 }else if((empty($nama_admin))){
	 	$response = new usr();
	 	$response->success = 0;
	 	$response->message = "Nama kamu gak boleh kosong";
	 	die(json_encode($response));
	 }else {
		 if (!empty($username) && $password == $confirm_password){
		 	$num_rows = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM akun WHERE username='".$username."'"));

		 	if ($num_rows == 0){

		$random = random_word(20);
		
		$path = "ikon/".$random.".png";
		$actualpath ="http://192.168.43.171/meme/$path";
		 		$query = mysqli_query($conn, "INSERT INTO akun (id_akun, username, password, nama_admin, deskripsi, ikon, email) VALUES(NULL,'".$username."','".$password."','".$nama_admin."','".$info."','".$path."','".$email."')");

	 		if ($query){
	 				file_put_contents($path,base64_decode($profil));
		 			$response = new usr();
		 			$response->success = 1;
		 			$response->message = "Register berhasil, silahkan login.";
		 			die(json_encode($response));

		 		} else {
		 			$response = new usr();
	 				$response->success = 0;
		 			$response->message = "Username sudah ada";
					die(json_encode($response));
		 		}
		 	} else {
		 		$response = new usr();
		 		$response->success = 0;
		 		$response->message = "Username sudah ada";
		 		die(json_encode($response));
	 	}
	}
 }
// fungsi random string pada gambar untuk menghindari nama file yang sama
	function random_word($id = 20){
		$pool = '1234567890abcdefghijkmnpqrstuvwxyz';
		
		$word = '';
		for ($i = 0; $i < $id; $i++){
			$word .= substr($pool, mt_rand(0, strlen($pool) -1), 1);
		}
		return $word; 
	}
	 mysqli_close($conn);

?>	