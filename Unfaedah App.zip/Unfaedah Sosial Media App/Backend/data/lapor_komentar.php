<?php
	include "koneksi.php";
	class usr{}

	$id_pelapor = $_POST["id_pelapor"];
	$id_komentar = $_POST["id_komentar"];
	$alasan = $_POST["alasan"];
	$keterangan =$_POST["keterangan"];

	$query = "INSERT INTO laporan_komentar (id_laporan, id_pelapor, id_komentar, alasan, keterangan) VALUES (NULL, '".$id_pelapor."', '".$id_komentar."', '".$alasan."', '".$keterangan."')";

	$sql = mysqli_query ($conn, $query);

	if ($sql){
		$response = new usr();
		$response->success = 1;
		$response->message = "Komentar dilaporkan";
		die(json_encode($response));
	}else{
		$response = new usr();
		$response->success = 0;
		$response->message = "Mohon maaf, ada kesalahan";
		die(json_encode($response));
	}

	mysqli_close($conn);

?>