<?php

  include "koneksi.php";
  
  $query = "SELECT  id_akun, deskripsi, ikon, nama_admin FROM akun  ORDER BY RAND()"; 
  $sql = mysqli_query($conn, $query);


  
 if(mysqli_num_rows($sql)>0){
  $response = array();
  while ($x = mysqli_fetch_array($sql)){
 
 
    $h['id_akun'] = $x["id_akun"];
    $h['nama_admin'] = $x["nama_admin"];
    $h['ikon'] = $x["ikon"];
    $h['deskripsi'] = $x["deskripsi"];
    array_push($response, $h);
  }
  echo json_encode($response);
  }else{
    $response["message"] = "tidak ada data";
    echo json_encode($response);
  }
  ?>