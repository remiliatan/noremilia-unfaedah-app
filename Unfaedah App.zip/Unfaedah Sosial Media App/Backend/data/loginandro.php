<?php
 include_once "koneksi.php";

	class usr{}
	
	$username = $_POST["username"];
	$password = $_POST["password"];
	
	if ((empty($username)) || (empty($password))) { 
	 	$response = new usr();
	 	$response->success = 0;
		$response->message = "Kolom tidak boleh kosong"; 
	 	die(json_encode($response));
	 }
	
	 $query = mysqli_query($conn, "SELECT* FROM  akun  WHERE username='$username' AND password='$password'" );
	
	 $row = mysqli_fetch_array($query);
	
	 if (!empty($row)){
	 	$response = new usr();
	 	$response->success = 1;
	 	$response->message = "Selamat datang ".$row['nama_admin'];
	 	$response->id_akun = $row['id_akun'];
	 	$response->ikon = $row['ikon'];
	 	$response->nama_admin = $row['nama_admin'];
	 	$response->username = $row['username'];
	 	$response->password = $row['password'];
	 	$response->email = $row['email'];
	 	$response->deskripsi = $row['deskripsi'];
	 	die(json_encode($response));
		
	 } else { 
	 	$response = new usr();
	 	$response->success = 0;
	 	$response->message = "Username atau password salah";
	 	die(json_encode($response));
	 }
	
	 mysqli_close($conn);

?>