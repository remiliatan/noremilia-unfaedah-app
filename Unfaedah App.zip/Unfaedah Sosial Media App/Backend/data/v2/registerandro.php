<?php
 include_once "koneksi.php";

class usr{}

	 $username = $_POST["username"];
	 $password = $_POST["password"];
	 $profil = $_POST["profil"];
	 $info = $_POST["info"];
	 $email = $_POST["email"];
	 $nama_admin= $_POST["nama_admin"];



	
		 	$num_rows = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM akun WHERE username='".$username."'"));

		 	if ($num_rows == 0){

		$random = random_word(20);
		
		$path = "ikon/".$random.".png";
		$actualpath ="http://192.168.43.171/meme/$path";
		 		$query = mysqli_query($conn, "INSERT INTO akun (id_akun, username, password, nama_admin, deskripsi, ikon, email) VALUES(NULL,'".$username."','".$password."','".$nama_admin."','".$info."','".$path."','".$email."')");

	 		if ($query){
	 				file_put_contents($path,base64_decode($profil));
		 			$response = new usr();
		 			$response->success = 1;
		 			$response->message = "Register berhasil, silahkan login disebelah kiri.";
		 			die(json_encode($response));

		 		} else {
		 			$response = new usr();
	 				$response->success = 0;
		 			$response->message = "Gagal";
					die(json_encode($response));
		 		}
		 	} else {
		 		$response = new usr();
		 		$response->success = 0;
		 		$response->message = "Username sudah ada";
		 		die(json_encode($response));
	 	}
	
 
// fungsi random string pada gambar untuk menghindari nama file yang sama
	function random_word($id = 20){
		$pool = '1234567890abcdefghijkmnpqrstuvwxyz';
		
		$word = '';
		for ($i = 0; $i < $id; $i++){
			$word .= substr($pool, mt_rand(0, strlen($pool) -1), 1);
		}
		return $word; 
	}
	 mysqli_close($conn);

?>	