 <?php

  include "koneksi.php";
  
  $query = "SELECT COUNT(komentar.id) as jumlah, suka.id_suka, suka.id_penyuka, suka.id_posting, akun.id_akun, akun.deskripsi, akun.ikon, akun.nama_admin, data.id, data.suka, data.caption, data.gambar, data.kategori, data.sumber, data.tanggal_dibuat FROM  akun INNER JOIN data ON akun.id_akun = data.id_akun LEFT JOIN suka ON akun.id_akun = suka.id_penyuka AND data.id = suka.id_posting LEFT JOIN komentar ON data.id = komentar.id WHERE data.kategori='info unik' GROUP BY data.id ORDER BY RAND() LIMIT 10"; 
  $sql = mysqli_query($conn, $query);

 if(mysqli_num_rows($sql)>0){
  $response = array();
  $i=0;
  while ($x = mysqli_fetch_array($sql)){
 
  $query2 = "SELECT * FROM suka where id_posting = '$x[id]'";
  $sql2= mysqli_query($conn, $query2);
  
   /* $h['id'] = $x["id"];
    $h['suka'] = $x["suka"];
    $h['id_akun'] = $x["id_akun"];
    $h['nama_admin'] = $x["nama_admin"];
    $h['ikon'] = $x["ikon"];
    $h['deskripsi'] = $x["deskripsi"];
    $h['caption'] = $x["caption"];
    $h['gambar'] = $x["gambar"];
    $h['kategori'] = $x["kategori"];
    $h['sumber'] = $x["sumber"];
    $h['jumlah'] = $x["jumlah"];*/


    $response[$i]= array("id"=>$x['id'],"suka"=>$x['suka'], "id_akun"=> $x['id_akun'], "nama_admin"=>$x['nama_admin'],
       "tanggal_dibuat" =>$x['tanggal_dibuat'],
      "ikon"=>$x['ikon'], "deskripsi"=>$x['deskripsi'], "caption"=>$x['caption'], "gambar"=>$x['gambar'], "kategori"=>$x['kategori'],
      "sumber"=>$x['sumber'], "jumlah"=>$x['jumlah'], "menyukai"=>[]);
   while($row1 = mysqli_fetch_array($sql2))
    {
        $response[$i]["menyukai"][] = array("id_penyuka"=>$row1['id_penyuka'],"id_posting"=>$row1['id_posting'],"id_suka"=>$row1['id_suka']);

    }  
  $i++;
}
  $rest = array();
  $rest['posting'] = $response;
  echo json_encode($rest);
  }else{
    $response["message"] = "tidak ada data";
    echo json_encode($response);
  }
  ?>