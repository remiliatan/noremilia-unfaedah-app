 <?php

  include "koneksi.php";
  
$id = $_POST["id"];

  $query = "SELECT komentar.*, akun.id_akun, akun.ikon, akun.nama_admin FROM komentar INNER JOIN akun ON komentar.id_akun = akun.id_akun WHERE komentar.id = '$id'";
  $sql = mysqli_query($conn, $query);

  $queryPosting = "SELECT COUNT(komentar.id) as jumlah, data.*, akun.* FROM data INNER JOIN akun ON data.id_akun = akun.id_akun LEFT JOIN komentar ON data.id = komentar.id WHERE data.id = '$id' GROUP BY id";
  $sqlPosting = mysqli_query($conn, $queryPosting);


  
 if(mysqli_num_rows($sqlPosting)>0){
  $response = array();
  while ($x = mysqli_fetch_array($sql)){
 
    $h['id'] = $x["id"];
    $h['id_akun'] = $x["id_akun"];
    $h['id_komentar'] = $x["id_komentar"];
    $h['komentar'] = $x["komentar"];
    
    $h['nama_admin'] = $x["nama_admin"];
    $h['ikon'] = $x["ikon"];
    array_push($response, $h);
  }

  $posting = mysqli_fetch_array($sqlPosting);
  $query2 = "SELECT * FROM suka where id_posting = '$posting[id]'";
  $sql2= mysqli_query($conn, $query2);
  $i=0;

  $posting= array("id"=>$posting['id'],
    "suka"=>$posting['suka'], 
    "id_akun"=> $posting['id_akun'], 
    "nama_admin"=>$posting['nama_admin'],
    "ikon"=>$posting['ikon'], 
    "deskripsi"=>$posting['deskripsi'], 
    "caption"=>$posting['caption'], 
    "tanggal_dibuat" =>$posting['tanggal_dibuat'],
    "gambar"=>$posting['gambar'], 
    "kategori"=>$posting['kategori'],
    "sumber"=>$posting['sumber'], 
    "jumlah"=>$posting['jumlah'], 
    "menyukai"=>[]);
  
 while($row1 = mysqli_fetch_array($sql2)){

        $posting["menyukai"][] = array("id_penyuka"=>$row1['id_penyuka'],"id_posting"=>$row1['id_posting'],"id_suka"=>$row1['id_suka']);
  $i++;    
}
  $rest = array();
  $rest['posting'] = $posting;
  $rest['komentar'] = $response;

  echo json_encode($rest);
  //echo json_encode($response);
  }else{
    $response["message"] = "tidak ada data";
    echo json_encode($response);
  }
  ?>