<?php
 include_once "koneksi.php";

class usr{}

	 $caption = $_POST["caption"];
	 $gambar = $_POST["gambar"];
	 $id_akun =$_POST["id_akun"];
	 $kategori = $_POST["kategori"];
	 $tanggal = $_POST["tanggal_dibuat"];
	



	 if ((empty($caption))) {
 		$response = new usr();
	 	$response->success = 0;
	 	$response->message = "Kolom caption tidak boleh kosong";
	 	die(json_encode($response));
	 
	 } else if((empty($gambar))){
	 	$response = new usr();
	 	$response->success = 0;
	 	$response->message = "Tolong tambahkan gambar";
	 	die(json_encode($response));
	 }else {

		 	

		$random = random_word(20);
		
		$path = "images/".$random.".png";
		$actualpath ="http://192.168.43.171/meme/$path";
		 		$query = mysqli_query($conn, "INSERT INTO data (id, id_akun, caption, gambar, kategori, tanggal_dibuat) VALUES(NULL,'".$id_akun."','".$caption."','".$path."','".$kategori."', '".$tanggal."')");

	 		if ($query){
	 				file_put_contents($path,base64_decode($gambar));
		 			$response = new usr();
		 			$response->success = 1;
		 			$response->message = "Kiriman kamu berhasil di upload.";
		 			die(json_encode($response));

		 		}
		 		}
	
// fungsi random string pada gambar untuk menghindari nama file yang sama
	function random_word($id = 20){
		$pool = '1234567890abcdefghijkmnpqrstuvwxyz';
		
		$word = '';
		for ($i = 0; $i < $id; $i++){
			$word .= substr($pool, mt_rand(0, strlen($pool) -1), 1);
		}
		return $word; 
	}
	 mysqli_close($conn);

?>	