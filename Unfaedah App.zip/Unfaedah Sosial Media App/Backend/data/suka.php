<?php

  include "koneksi.php";



 if (isset($_POST['suka'])) {
		$postid = $_POST['id'];
		$id_akun = $_POST['id_akun'];
		$result = mysqli_query($conn, "SELECT * FROM data WHERE id='$postid';");
		$row = mysqli_fetch_array($result);
		$n = $row['suka'];

		mysqli_query($conn, "INSERT INTO suka (id_suka, id_posting, id_penyuka) VALUES (NULL, '".$postid."', '".$id_akun."')");
		mysqli_query($conn, "UPDATE data SET suka='$n'+1 WHERE id='$postid';");

		echo $n+1;
	}
	if (isset($_POST['tidak_suka'])) {
		$postid = $_POST['id'];
		$id_akun = $_POST['id_akun'];
		$result = mysqli_query($conn, "SELECT * FROM data WHERE id='$postid';");
		$row = mysqli_fetch_array($result);
		$n = $row['suka'];

		mysqli_query($conn, "DELETE FROM suka WHERE id_posting='$postid' AND id_penyuka='$id_akun';");
		mysqli_query($conn, "UPDATE data SET suka='$n'-1 WHERE id='$postid'");
		
		echo $n-1;
	}


	 mysqli_close($conn);
?>