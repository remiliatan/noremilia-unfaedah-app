package com.novalnvall.memeunfaedah.Activity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.novalnvall.memeunfaedah.R;
import com.novalnvall.memeunfaedah.Util.Server;
import com.novalnvall.memeunfaedah.adapter.TabbedAdapter;
import com.novalnvall.memeunfaedah.fragment.AccountTab1;
import com.novalnvall.memeunfaedah.fragment.AccountTab2;
import com.novalnvall.memeunfaedah.fragment.Bola;
import com.novalnvall.memeunfaedah.fragment.FragmentGame;
import com.novalnvall.memeunfaedah.fragment.InfounikFragment;
import com.novalnvall.memeunfaedah.fragment.Login;
import com.novalnvall.memeunfaedah.fragment.QuotesFragment;
import com.novalnvall.memeunfaedah.fragment.Shitpost;
import com.squareup.picasso.Picasso;



import de.hdodenhof.circleimageview.CircleImageView;

public class GalleryActivity extends AppCompatActivity {



      TabbedAdapter adapter;
      ViewPager viewpager;
      TabLayout tabLayout;
      FloatingActionButton  fbformkirim;
      CircleImageView pro;

      ImageView search;
      AdView adView;

      SharedPreferences sharedPreferences;

      public static final String TAG_PROFIL = "ikon";

      String ikonUrl= Server.URL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gallery);
        pro = findViewById(R.id.go_pro);

        sharedPreferences = getSharedPreferences(Login.my_shared_preferences, Context.MODE_PRIVATE);


        fbformkirim = findViewById(R.id.fbkirim);
        search = findViewById(R.id.btncari);

        /*//iklan
        MobileAds.initialize(this, getResources().getString(R.string.kode_app_asli));
        adView = new AdView(this);
        adView.setAdSize(AdSize.SMART_BANNER);
        adView.setAdUnitId(getResources().getString(R.string.kode_banner_asli));
        adView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);*/

        Intent dataExtra= getIntent();
        String ikon= dataExtra.getStringExtra(TAG_PROFIL);

        Picasso.get().load(ikonUrl + ikon).into(pro);

        viewpager = findViewById(R.id.vp_containerELearning);
        tabLayout = findViewById(R.id.tl_tabsAbsence);
        tabLayout.setupWithViewPager(viewpager);
        tabLayout.setTabMode(TabLayout.MODE_SCROLLABLE);
        adapter = new TabbedAdapter(getSupportFragmentManager());
        adapter.addFragment(AccountTab1.newInstance(getSupportFragmentManager()), "Random");
        adapter.addFragment(AccountTab2.newInstance(getSupportFragmentManager()), "Anime");
        adapter.addFragment(FragmentGame.newInstance(getSupportFragmentManager()),"Game");
        adapter.addFragment(Shitpost.newInstance(getSupportFragmentManager()), "Aneh");
        adapter.addFragment(InfounikFragment.newInstance(getSupportFragmentManager()), "Info Unik");
        adapter.addFragment(Bola.newInstance(getSupportFragmentManager()),"Troll Bola");
        adapter.addFragment(QuotesFragment.newInstance(getSupportFragmentManager()),"Quotes");
        viewpager.setAdapter(adapter);


        pro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(GalleryActivity.this, My_info.class);
                Intent bundle = getIntent();

                if(bundle != null){
                    intent.putExtras(bundle);
                }
                startActivity(intent);
            }
        });

        fbformkirim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(GalleryActivity.this, ActivityKiriman.class);
                Intent bundle = getIntent();

                if(bundle != null){
                    intent.putExtras(bundle);
                }
                startActivity(intent);
            }
        });

        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent (GalleryActivity.this, SearchActivity.class);
                startActivity(i);
            }
        });


    }


    public void onBackPressed(){
     AlertDialog.Builder builder = new AlertDialog.Builder(GalleryActivity.this);
     builder.setTitle("Exit");
     builder.setMessage("Keluar dari aplikasi UNFAEDAH");
     builder.setPositiveButton("Iya", new DialogInterface.OnClickListener() {
         @Override
         public void onClick(DialogInterface dialogInterface, int i) {
             Intent a = new Intent(Intent.ACTION_MAIN);
             a.addCategory(Intent.CATEGORY_HOME);
             a.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
             startActivity(a);
         }
     });
     builder.setNeutralButton("Tidak", new DialogInterface.OnClickListener() {
         @Override
         public void onClick(DialogInterface dialogInterface, int i) {
             Log.e("INFO", "OK");
         }
     });
     builder.show();
 }


}
