package com.novalnvall.memeunfaedah.Activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.novalnvall.memeunfaedah.R;
import com.novalnvall.memeunfaedah.Util.Server;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Reset_Password extends AppCompatActivity {

    Button reset;
    EditText confirm, baru;
    ProgressDialog progressDialog;

    String urlGanti = Server.URL + "ganti_password.php";
    int success;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset__password);

        reset = findViewById(R.id.bsimpan_reset);
        confirm = findViewById(R.id.confirm_reset);
        baru = findViewById(R.id.barureset);

        Intent intent = getIntent();
        final String id_akun = intent.getStringExtra("id_akun");

        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String pkonfirm = confirm.getText().toString();
                String pbaru = baru.getText().toString();

                if (pkonfirm.trim().length() > 4 && pbaru.trim().length() > 4){
                    if (!pbaru.equals(pkonfirm)){
                        Toast.makeText(Reset_Password.this, "Password baru dan konfirmasi password harus sama", Toast.LENGTH_SHORT).show();
                    }else {
                        resetPassword(pbaru, id_akun);

                    }
                }else{
                    Toast.makeText(Reset_Password.this, "Password harus lebih dari 4 huruf", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void resetPassword(final String pbaru, final String id_akun){
        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Memproses");
        showDialog();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, urlGanti, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                hideDialog();

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    success = jsonObject.getInt("success");
                    if (success == 1) {
                        Intent intent = new Intent(Reset_Password.this, loginregis.class);
                        startActivity(intent);
                        Toast.makeText(Reset_Password.this, "Reset password berhasil, silahkan login", Toast.LENGTH_SHORT).show();
                    } else
                        Toast.makeText(Reset_Password.this, "Maaf, coba lagi", Toast.LENGTH_SHORT).show();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Reset_Password.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String>getParams(){
                Map<String, String> params = new HashMap<>();
                params.put("id_akun", id_akun);
                params.put("password", pbaru);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }
    private void showDialog(){
        if (!progressDialog.isShowing())
            progressDialog.show();
    }
    private void hideDialog(){
        if (progressDialog.isShowing())
            progressDialog.dismiss();
    }

}
