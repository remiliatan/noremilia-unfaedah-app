package com.novalnvall.memeunfaedah.Activity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.novalnvall.memeunfaedah.R;
import com.novalnvall.memeunfaedah.Util.Server;
import com.novalnvall.memeunfaedah.fragment.Login;
import com.squareup.picasso.Picasso;

import de.hdodenhof.circleimageview.CircleImageView;

public class My_info extends AppCompatActivity {
    CircleImageView mypro ;
    Button out;
    String id_akun, username, nama_admin, profil;
    TextView myname, atur, tentang, ikuti, pembaruan;
    SharedPreferences sharedpreferences;

    public static final String TAG_ID = "id_akun";
    public static final String TAG_USERNAME = "username";
    public static final String TAG_ADMIN = "nama_admin";
    public static final String TAG_PROFIL = "ikon";

    private String ikonUrl= Server.URL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_info);

        mypro = findViewById(R.id.my_info);
        out = findViewById(R.id.logout);
        myname = findViewById(R.id.name_pro);
        atur = findViewById(R.id.settings);
        tentang = findViewById(R.id.about);
        ikuti = findViewById(R.id.favorit);
        pembaruan = findViewById(R.id.update);


        sharedpreferences = getSharedPreferences(Login.my_shared_preferences, Context.MODE_PRIVATE);


        Intent dataExtra = getIntent();
        String ikon = dataExtra.getStringExtra(TAG_PROFIL);
        String nama_admin = dataExtra.getStringExtra(TAG_ADMIN);


        Log.e("IKON", String.valueOf(ikon));

      myname.setText(nama_admin);

      Picasso.get().load(ikonUrl+ ikon).into(mypro);


      ikuti.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View view) {
              Toast.makeText(My_info.this, "Bagian ini masih tahap pengembangan", Toast.LENGTH_SHORT).show();
          }
      });
        out.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(My_info.this);
                builder.setTitle("Keluar");
                builder.setMessage("Kamu yakin mau Logout?");
                builder.setPositiveButton("Iya", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        SharedPreferences.Editor editor = sharedpreferences.edit();
                        editor.putBoolean(Login.session_status, false);
                        editor.putString(TAG_ID, null);
                        editor.putString(TAG_USERNAME, null);
                        editor.putString(TAG_PROFIL, null);
                        editor.apply();

                        Intent intent = new Intent(My_info.this, loginregis.class);
                        startActivity(intent);

                        Toast.makeText(My_info.this, "Kamu berhasil keluar", Toast.LENGTH_SHORT).show();
                    }
                });
                builder.setNeutralButton("Tidak", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Log.e("OK", "OK");
                    }
                });
                builder.show();
            }
        });
        atur.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(My_info.this, UpdateAkun.class);
                Intent bundle = getIntent();

                if(bundle != null){
                    intent.putExtras(bundle);
                }
                startActivity(intent);
            }
        });

        mypro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(My_info.this, MainActivity.class);
                Intent bundle = getIntent();

                if(bundle != null){
                    intent.putExtras(bundle);
                }
                startActivity(intent);
            }
        });
        myname.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(My_info.this, MainActivity.class);
                Intent bundle = getIntent();

                if(bundle != null){
                    intent.putExtras(bundle);
                }
                startActivity(intent);
            }
        });

        tentang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(My_info.this, AboutApp.class);
                Intent bundle = getIntent();

                if(bundle != null){
                    intent.putExtras(bundle);
                }
                startActivity(intent);
            }
        });

        pembaruan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final AlertDialog.Builder alertDialog = new AlertDialog.Builder(My_info.this);
                alertDialog.setTitle("Periksa Pembaruan");
                alertDialog.setMessage("Klik Iya untuk memeriksa pembaruan. Jika terdapat tulisan 'Update' maka kamu harus memperbarui Aplikasi");
                alertDialog.setPositiveButton("Iya", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        final String pack = getPackageName();
                        Intent intent = new Intent(Intent.ACTION_VIEW);
                        intent.setData(Uri.parse("https://play.google.com/store/apps/details?id=" + pack));
                        startActivity(intent);
                    }
                });
                alertDialog.setNegativeButton("Nanti", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        alertDialog.create().dismiss();
                    }
                });
                alertDialog.show();

            }
        });

    }
    public void onBackPressed(){
        Intent intent = new Intent(My_info.this, GalleryActivity.class);
        Intent bundle = getIntent();

        if(bundle != null){
            intent.putExtras(bundle);
        }
        startActivity(intent);
    }
    }

