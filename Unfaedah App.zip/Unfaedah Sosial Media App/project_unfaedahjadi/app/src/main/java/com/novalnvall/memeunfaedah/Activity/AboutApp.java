package com.novalnvall.memeunfaedah.Activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.design.widget.CoordinatorLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.novalnvall.memeunfaedah.R;
import com.novalnvall.memeunfaedah.Util.Server;
import com.squareup.picasso.Picasso;

public class AboutApp extends AppCompatActivity {
    TextView tos, nama, privasi, rating;
    ImageView ikona;
    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_app);

        tos =  findViewById(R.id.termofservice);
        nama = findViewById(R.id.namaapp);
        privasi = findViewById(R.id.privacy);
        ikona = findViewById(R.id.ikonapp);
        rating = findViewById(R.id.rate);

        Picasso.get().load(Server.URL + "ikon/ikon_unfaedah.png").placeholder((R.color.white)).into(ikona);

        try {
            PackageInfo packageInfo = this.getPackageManager().getPackageInfo(getPackageName(),0);
            String info = packageInfo.versionName;
            nama.setText("Unfaedah v"+info);
        }catch (PackageManager.NameNotFoundException e){
            e.printStackTrace();
        }

        tos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("https://unfaedah.id/kebijakan/term-of-service.html"));
                startActivity(intent);
            }
        });

        privasi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("https://unfaedah.id/kebijakan/privacy-police.html"));
                startActivity(intent);
            }
        });

        rating.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String pack = getPackageName();
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("https://play.google.com/store/apps/details?id=" + pack));
                startActivity(intent);
            }
        });
    }
}
