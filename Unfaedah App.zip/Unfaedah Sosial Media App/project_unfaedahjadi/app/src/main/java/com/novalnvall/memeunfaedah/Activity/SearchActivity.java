package com.novalnvall.memeunfaedah.Activity;

import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.novalnvall.memeunfaedah.R;
import com.novalnvall.memeunfaedah.Util.Server;
import com.novalnvall.memeunfaedah.adapter.SearchAdapter;
import com.novalnvall.memeunfaedah.model.Gallery;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class SearchActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private SearchAdapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    private ArrayList <Gallery> searchArrayList;
    private LinearLayout tidak_cari, gakada;
    private TextView nama;
    SearchView searchView;

    String id_akun;
    ProgressBar progressBar;
    private AdView adView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        progressBar = findViewById(R.id.progress_bar2);
        searchView = findViewById(R.id.search2);
        tidak_cari = findViewById(R.id.tidak_ada_search);
        gakada = findViewById(R.id.tidak_ketemu);
        nama = findViewById(R.id.not_found);

        searchArrayList = new ArrayList<>();
        recyclerView = findViewById(R.id.recysearch);

        layoutManager = new LinearLayoutManager( this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);

        recyclerView.setItemAnimator( new DefaultItemAnimator());
        DividerItemDecoration itemDecoration = new DividerItemDecoration(getApplicationContext(), DividerItemDecoration.VERTICAL);
        itemDecoration.setDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.textlines));
        recyclerView.addItemDecoration(itemDecoration);


        adapter = new SearchAdapter(this, searchArrayList);
        recyclerView.setAdapter(adapter);
        gakada.setVisibility(View.GONE);

        //iklan
        MobileAds.initialize(this, getResources().getString(R.string.kode_app_asli));
        adView = new AdView(this);
        adView.setAdSize(AdSize.SMART_BANNER);
        adView.setAdUnitId(getResources().getString(R.string.kode_banner_asli));
        adView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);


        EditText searchEditText = searchView.findViewById(android.support.v7.appcompat.R.id.search_src_text);
        searchEditText.setTextColor(Color.BLACK);
        searchEditText.setHintTextColor(getResources().getColor(R.color.gray));
        searchEditText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);


        Drawable img = getApplicationContext().getResources().getDrawable( R.drawable.ic_search22);
        searchEditText.setCompoundDrawablesWithIntrinsicBounds( img, null, null, null);

        searchView.setFocusable(true);
        searchView.setIconified(false);
        searchView.requestFocusFromTouch();

        searchView.setQueryHint("Cari Orang");

        ImageView searchViewIcon = searchView.findViewById(android.support.v7.appcompat.R.id.search_close_btn);
        searchViewIcon.setVisibility(View.GONE);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                cariNama(query);
                tidak_cari.setVisibility(View.GONE);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String nextText) {
                ImageView searchViewIcon = searchView.findViewById(android.support.v7.appcompat.R.id.search_close_btn);
                searchViewIcon.setColorFilter(getResources().getColor(R.color.colorAccent));
                searchViewIcon.setVisibility(View.VISIBLE);
                tidak_cari.setVisibility(View.GONE);

                if(searchViewIcon.isClickable()){
                    recyclerView.setVisibility(View.VISIBLE);
                }
               /* nextText = nextText.toLowerCase();
                ArrayList <Gallery> dataFilter = new ArrayList<>();
                for (Gallery data : searchArrayList){
                    String nama = data.getNama_admin().toLowerCase();
                    if (nama.contains(nextText)){
                        dataFilter.add(data);
                    }
                }
                adapter.setFilter(dataFilter);*/
                if(nextText.trim().length() == 0){
                    gakada.setVisibility(View.GONE);
                    searchViewIcon.setVisibility(View.GONE);
                }
                return true;
            }
        });
        hideProgressBar();
    }

    private void cariNama(final String keyword){
        final String cariUrl= Server.URL + "cari_data.php";
        showProgressBar();
        StringRequest stringRequest = new StringRequest(Request.Method.POST, cariUrl, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    int value = jsonObject.getInt("value");

                    if (value == 1) {
                        searchArrayList.clear();
                        adapter.notifyDataSetChanged();
                        JSONArray jsonArray = jsonObject.getJSONArray("results");
                        for (int l = 0; l < jsonArray.length(); l++) {
                            JSONObject object = jsonArray.getJSONObject(l);
                            Gallery gallery = new Gallery();
                            gallery.setNama_admin(object.getString("nama_admin"));
                            gallery.setId_akun(object.getString("id_akun"));
                            gallery.setDeskripsi(object.getString("deskripsi"));
                            gallery.setIkon(object.getString("ikon"));
                            searchArrayList.add(gallery);
                        }
                    } else {
                        gakada.setVisibility(View.VISIBLE);
                        recyclerView.setVisibility(View.GONE);
                        tidak_cari.setVisibility(View.GONE);
                        nama.setText("Maaf, orang dengan nama '"+ keyword + "' tidak ditemukan" );
                        Toast.makeText(SearchActivity.this, "Tidak ditemukan", Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                adapter.notifyDataSetChanged();
                hideProgressBar();
            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(SearchActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams(){
                Map<String, String> params = new HashMap<>();
                params.put("keyword", keyword);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue( SearchActivity.this);
        requestQueue.add(stringRequest);
    }

    private void DaftarSearch(){
        final String jsonUrl= Server.URL + "searchlist.php";
        showProgressBar();

        JsonArrayRequest jsonArrayRequest =  new JsonArrayRequest(jsonUrl, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                searchArrayList.clear();
                Log.e("ERROR LOAD", String.valueOf(response));
                for (int i = 0; i < response.length(); i++) {
                    try {
                        JSONObject jsonObject = response.getJSONObject(i);
                        Gallery gallery = new Gallery();
                        gallery.setNama_admin(jsonObject.getString("nama_admin"));
                        gallery.setIkon(jsonObject.getString("ikon"));
                        gallery.setId_akun(jsonObject.getString("id_akun"));
                        gallery.setDeskripsi(jsonObject.getString("deskripsi"));
                        searchArrayList.add(gallery);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                adapter.notifyDataSetChanged();
                hideProgressBar();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("Volley", error.toString());
            }
        }){
            @Override
            protected Map<String, String> getParams(){
                Map<String, String>params = new HashMap<>();

                params.put("id_akun", id_akun);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(jsonArrayRequest);

    }

    private void showProgressBar() {
        progressBar.setVisibility(View.VISIBLE);
    }

    private void hideProgressBar() {
        progressBar.setVisibility(View.GONE);
    }

}
