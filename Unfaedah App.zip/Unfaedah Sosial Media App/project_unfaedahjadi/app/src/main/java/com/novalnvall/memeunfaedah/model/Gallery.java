package com.novalnvall.memeunfaedah.model;

public class Gallery {
    private String id;
    private String nama_admin;
    private String caption;
    private String id_komentar;
    private String komentar;
    private String sumber;
    private String profil;
    private String gambar;
    private String is_liked;
    private String id_akun;
    private String ikon;
    private String kategori;
    private String penyuka;
    private String dibuat;
    private String id_suka;
    private String pengikut;
    private ItemType type;
    private String suka;
    private boolean klik;

    public String getJumlah() {
        return jumlah;
    }

    public void setJumlah(String jumlah) {
        this.jumlah = jumlah;
    }

    private String deskripsi;
    public String likes;
    public String jumlah;

    public Gallery() {

    }

    public Gallery(int i, ItemType oneItem) {
    }

    public enum ItemType{
        ONE_ITEM, TWO_ITEM
    }


    public String getDeskripsi() {
        return deskripsi;
    }

    public void setDeskripsi(String deskripsi) {
        this.deskripsi = deskripsi;
    }

    public String getId_akun() {
        return id_akun;
    }

    public void setId_akun(String id_akun) {
        this.id_akun = id_akun;
    }

    public String getIs_liked() {
        return is_liked;
    }

    public void setIs_liked(String is_liked) {
        this.is_liked = is_liked;
    }

    public String getId_komentar() {
        return id_komentar;
    }

    public void setId_komentar(String id_komentar) {
        this.id_komentar = id_komentar;
    }

    public String getKomentar() {
        return komentar;
    }

    public void setKomentar(String komentar) {
        this.komentar = komentar;
    }

    public String getId_suka() {
        return id_suka;
    }

    public void setId_suka(String id_suka) {
        this.id_suka = id_suka;
    }

    public String getSuka() {
        return suka;
    }

    public void setSuka(String suka) {
        this.suka = suka;
    }

    public String getPenyuka() {
        return penyuka;
    }

    public void setPenyuka(String penyuka) {
        this.penyuka = penyuka;
    }


    public boolean isKlik() {
        return klik;
    }

    public void setKlik(boolean klik) {
        this.klik = klik;
    }

    public String getPengikut() {
        return pengikut;
    }

    public void setPengikut(String pengikut) {
        this.pengikut = pengikut;
    }

    public String getDibuat() {
        return dibuat;
    }

    public void setDibuat(String dibuat) {
        this.dibuat = dibuat;
    }

    public Gallery(String dibuat, String pengikut, boolean klik, String penyuka, String suka, String id_suka, String jumlah, String is_liked, String komentar, String id_komentar, String id_akun, String  id, String deskripsi, ItemType type, String nama_admin, String caption, String sumber, String gambar, String ikon, String kategori, String profil) {
        this.id = id;
        this.type= type;
        this.klik = klik;
        this.dibuat = dibuat;

        this.pengikut = pengikut;

        this.komentar = komentar;
        this.suka = suka;
        this.penyuka = penyuka;


        this.id_suka = id_suka;

        this.id_komentar = id_komentar;
        this.is_liked = is_liked;
        this.id_akun = id_akun;

        this.jumlah = jumlah;
        this.nama_admin = nama_admin;
        this.gambar = gambar;
        this.ikon = ikon;
        this.kategori = kategori;
        this.profil = profil;
        this.deskripsi = deskripsi;


        this.caption = caption;
        this.sumber = sumber;


    }
    public ItemType getType() {
        return type;
    }

    public void setType(ItemType type) {
        this.type = type;
    }
    public String getKategori() {
        return kategori;
    }

    public void setKategori(String kategori) {
        this.kategori = kategori;
    }

    public String getIkon() {
        return ikon;
    }

    public void setIkon(String ikon) {
        this.ikon = ikon;
    }

    public String getProfil() {
        return profil;
    }

    public void setProfil(String profil) {
        this.profil = profil;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNama_admin() {
        return nama_admin;
    }

    public void setNama_admin(String nama_admin) {
        this.nama_admin = nama_admin;
    }

    public String getCaption() {
        return caption;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }

    public String getSumber() {
        return sumber;
    }

    public void setSumber(String sumber) {
        this.sumber = sumber;
    }

    public String getGambar() {
        return gambar;
    }

    public void setGambar(String gambar) {
        this.gambar = gambar;
    }


}


