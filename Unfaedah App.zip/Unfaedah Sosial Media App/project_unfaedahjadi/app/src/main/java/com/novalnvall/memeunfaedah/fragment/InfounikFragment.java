package com.novalnvall.memeunfaedah.fragment;


import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.widget.NestedScrollView;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.novalnvall.memeunfaedah.R;
import com.novalnvall.memeunfaedah.Util.Server;
import com.novalnvall.memeunfaedah.adapter.GalleryAdapter;
import com.novalnvall.memeunfaedah.adapter.TabbedAdapter;
import com.novalnvall.memeunfaedah.model.Gallery;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class InfounikFragment extends Fragment implements SwipeRefreshLayout.OnRefreshListener {
    private FragmentManager fragmentManager;
    private View view;
    private ProgressBar progressBar;
    private TabbedAdapter adapter;
    private RecyclerView recyclerView;
    private SwipeRefreshLayout swipeRefreshLayout;
    private Context mContext;
    private ProgressDialog mPrgoresDialog;
    private Snackbar mSnackbar;
    private GalleryAdapter mAdapter;
    private ArrayList<Gallery> galleryArrayList;
    private ArrayList<Gallery>likeArrayList;
    private RequestQueue requestQueue;
    private Button muat_ulang;
    private ConnectivityManager connectivityManager;
    private LinearLayout no_internet;
    CoordinatorLayout snak;
    private NestedScrollView nestedScrollView;
    private AdView adView;

    public final static  String TAG_USERNAME = "username";
    public final static String TAG_ID = "id_akun";

    SharedPreferences sharedPreferences;
    String id_akun, username;


    public void setFragmentManager(FragmentManager fragmentManager) {
        this.fragmentManager = fragmentManager;
    }

    public static InfounikFragment newInstance(FragmentManager fragmentManager) {
        InfounikFragment fragment = new InfounikFragment();
        fragment.setFragmentManager(fragmentManager);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        //Fragment Random
        view = inflater.inflate(R.layout.fragment_infounik, container, false);
        progressBar = view.findViewById(R.id.progress_bar);
        muat_ulang = view.findViewById(R.id.refresh);
        no_internet = view.findViewById(R.id.tidak_ada1);
        snak = view.findViewById(R.id.snack);
        nestedScrollView = view.findViewById(R.id.nestedScroll);


        // Swipe refresh
        swipeRefreshLayout = view.findViewById(R.id.swipe);
        swipeRefreshLayout.setColorSchemeColors(getResources().getColor(R.color.colorPrimaryDark));
        swipeRefreshLayout.setOnRefreshListener(this);

        // Recycle View
        recyclerView = view.findViewById(R.id.recy);

        //iklan
        MobileAds.initialize(getContext(), getResources().getString(R.string.kode_app_asli));
        adView = new AdView(getContext());
        adView.setAdSize(AdSize.BANNER);
        adView.setAdUnitId(getResources().getString(R.string.kode_banner_asli));
        adView = view.findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);





        loadData();
        // Adapter
        galleryArrayList = new ArrayList<>();
        mAdapter = new GalleryAdapter(getActivity(), galleryArrayList);
        final LinearLayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(mAdapter);

        muat_ulang.setVisibility(View.GONE);

        nestedScrollView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() {
            @Override
            public void onScrollChange(NestedScrollView v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
                Display display =  getActivity().getWindowManager().getDefaultDisplay();
                final int stageHeight = display.getHeight();
                int currentHeight = stageHeight + scrollY;
                int maxHeight = recyclerView.getHeight();

                if(currentHeight >= maxHeight){
                    muat_ulang.setVisibility(View.VISIBLE);
                }else {
                    muat_ulang.setVisibility(View.GONE);
                }

            }

        });


        /*recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
                if (newState == RecyclerView.SCROLL_INDICATOR_TOP){
                    muat_ulang.setVisibility(View.GONE);
                }
            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

            }
        });*/
        no_internet.setVisibility(View.GONE);
        connectivityManager = (ConnectivityManager)getActivity().getSystemService(getContext().CONNECTIVITY_SERVICE);
        {
            if(connectivityManager.getActiveNetworkInfo()!=null
                    && connectivityManager.getActiveNetworkInfo().isAvailable()
                    && connectivityManager.getActiveNetworkInfo().isConnected()){
                no_internet.setVisibility(View.GONE);
            }else{
                no_internet.setVisibility(View.VISIBLE);
                swipeRefreshLayout.setRefreshing(false);
                mSnackbar = Snackbar.make(snak, "Tidak ada koneksi internet", Snackbar.LENGTH_INDEFINITE).setAction("Coba Lagi", new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        loadData();
                    }
                });
            }
        }

        muat_ulang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                connectivityManager = (ConnectivityManager)getContext().getSystemService(getContext().CONNECTIVITY_SERVICE);
                {
                    if(connectivityManager.getActiveNetworkInfo()!=null
                            && connectivityManager.getActiveNetworkInfo().isAvailable()
                            && connectivityManager.getActiveNetworkInfo().isConnected()){
                        nestedScrollView.fullScroll(View.FOCUS_UP);
                        nestedScrollView.scrollTo(0, 0);

                        loadData();
                        muat_ulang.setVisibility(View.GONE);
                    }else{
                        nestedScrollView.fullScroll(View.FOCUS_UP);
                        nestedScrollView.scrollTo(0, 0);

                        muat_ulang.setVisibility(View.GONE);
                        Toast.makeText(getContext(), "Gagal memuat, cek koneksi internet", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        return view;
    }

    private void loadData(){
        String jsonUrl= Server.URL + "indexinfo_unik.php";
        showProgressBar();

        StringRequest jsonArrayRequest =  new StringRequest(jsonUrl, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                galleryArrayList.clear();
                Log.e("ERROR LOAD", String.valueOf(response));




                try {
                    JSONObject jsonObject1 = new JSONObject(response);

                    JSONArray jsonArray = jsonObject1.getJSONArray("posting");
                    JSONArray jsonMenyukai;

                    for (int i = 0; i < jsonArray.length() ; i++) {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        Gallery gallery = new Gallery();

                        jsonMenyukai = jsonObject.getJSONArray("menyukai");

                        if (jsonMenyukai.length() > 0) {


                            gallery.setCaption(jsonObject.getString("caption"));
                            gallery.setNama_admin(jsonObject.getString("nama_admin"));
                            gallery.setIkon(jsonObject.getString("ikon"));
                            gallery.setSumber(jsonObject.getString("sumber"));
                            gallery.setDibuat(jsonObject.getString("tanggal_dibuat"));
                            gallery.setSuka(jsonObject.getString("suka"));
                            gallery.setGambar(jsonObject.getString("gambar"));
                            gallery.setKategori(jsonObject.getString("kategori"));
                            gallery.setId(jsonObject.getString("id"));
                            gallery.setId_akun(jsonObject.getString("id_akun"));
                            gallery.setJumlah(jsonObject.getString("jumlah"));

                            for (int l = 0; l < jsonMenyukai.length(); l++) {
                                JSONObject object = jsonMenyukai.getJSONObject(l);
                                gallery.setId_suka(object.getString("id_suka"));
                                gallery.setPenyuka(object.getString("id_penyuka"));
                                gallery.setIs_liked(object.getString("id_posting"));
                            }
                                galleryArrayList.add(gallery);


                        }else {

                            gallery.setCaption(jsonObject.getString("caption"));
                            gallery.setNama_admin(jsonObject.getString("nama_admin"));
                            gallery.setIkon(jsonObject.getString("ikon"));
                            gallery.setSumber(jsonObject.getString("sumber"));
                            gallery.setSuka(jsonObject.getString("suka"));
                            gallery.setDibuat(jsonObject.getString("tanggal_dibuat"));
                            gallery.setGambar(jsonObject.getString("gambar"));
                            gallery.setKategori(jsonObject.getString("kategori"));
                            gallery.setId(jsonObject.getString("id"));
                            gallery.setId_akun(jsonObject.getString("id_akun"));
                            gallery.setJumlah(jsonObject.getString("jumlah"));

                                galleryArrayList.add(gallery);

                        }
                    }


                }catch (JSONException e) {
                    e.printStackTrace();
                }
                mAdapter.notifyDataSetChanged();
                hideProgressBar();
                swipeRefreshLayout.setRefreshing(false);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("Volley", error.toString());

                hideProgressBar();
                mSnackbar = Snackbar.make(swipeRefreshLayout,"Coba Lagi", Snackbar.LENGTH_INDEFINITE).setAction("RETRY", new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        loadData();
                    }
                });
            }
        }){
            @Override
            protected Map<String, String> getParams(){
                Map<String, String>params = new HashMap<>();

                params.put("id_akun", id_akun);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        requestQueue.add(jsonArrayRequest);

    }

    private void showProgressBar() {
        progressBar.setVisibility(View.VISIBLE);
    }

    private void hideProgressBar() {
        progressBar.setVisibility(View.GONE);
    }

    private void updateProgressBar(int progress) {
        progressBar.setProgress(progress);
    }

    @Override
    public void onRefresh() {
        loadData();

        no_internet.setVisibility(View.GONE);
    }


}
