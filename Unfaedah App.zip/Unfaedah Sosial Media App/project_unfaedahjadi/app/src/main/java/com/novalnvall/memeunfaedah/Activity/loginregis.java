package com.novalnvall.memeunfaedah.Activity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.novalnvall.memeunfaedah.R;
import com.novalnvall.memeunfaedah.adapter.TabbedAdapter;
import com.novalnvall.memeunfaedah.fragment.Daftar;
import com.novalnvall.memeunfaedah.fragment.Login;

public class loginregis extends AppCompatActivity {

    private TabbedAdapter adapter;
    private ViewPager viewpager;
    private TabLayout tabLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loginregis);




        viewpager = findViewById(R.id.vp_containerELearning);
        tabLayout = findViewById(R.id.tl_tabsAbsence);
        tabLayout.setupWithViewPager(viewpager);
        tabLayout.setTabMode(TabLayout.MODE_FIXED);


        adapter = new TabbedAdapter(getSupportFragmentManager());
        adapter.addFragment(Login.newInstance(getSupportFragmentManager()), "Login");
        adapter.addFragment(Daftar.newInstance(getSupportFragmentManager()), "DAFTAR");
        viewpager.setAdapter(adapter);
    }

    public void onBackPressed(){
        AlertDialog.Builder builder = new AlertDialog.Builder(loginregis.this);
        builder.setTitle("Exit");
        builder.setMessage("Keluar dari aplikasi UNFAEDAH");
        builder.setPositiveButton("Iya", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Intent a = new Intent(Intent.ACTION_MAIN);
                a.addCategory(Intent.CATEGORY_HOME);
                a.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(a);
            }
        });
        builder.setNeutralButton("Tidak", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Log.e("INFO", "OK");
            }
        });
        builder.show();
    }
}
