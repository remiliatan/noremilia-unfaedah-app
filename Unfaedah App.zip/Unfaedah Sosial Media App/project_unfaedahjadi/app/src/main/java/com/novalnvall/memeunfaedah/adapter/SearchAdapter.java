package com.novalnvall.memeunfaedah.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.novalnvall.memeunfaedah.Activity.MainActivity;
import com.novalnvall.memeunfaedah.R;
import com.novalnvall.memeunfaedah.Util.Server;
import com.novalnvall.memeunfaedah.model.Gallery;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class SearchAdapter extends RecyclerView.Adapter<SearchAdapter.SearchViewHolder> {

    private LayoutInflater inflater;
    private ArrayList <Gallery>searchArrayList;
    private String ikonUrl = Server.URL;
    private Context context;

    public SearchAdapter (Context context, ArrayList<Gallery>searchArrayList){
        inflater = LayoutInflater.from(context);
        this.searchArrayList = searchArrayList;
        this.context = context;
    }
    @Override
    public SearchAdapter.SearchViewHolder onCreateViewHolder (ViewGroup parent, int viewType){
        View view = inflater.inflate(R.layout.search_item, parent, false);
        SearchViewHolder holder = new SearchViewHolder (view);
        return  holder;
    }
   @Override
   public void onBindViewHolder (final SearchViewHolder holder, final int position) {
       holder.admin.setText(searchArrayList.get(position).getNama_admin());
       holder.deskripsi.setText(searchArrayList.get(position).getDeskripsi());

       Picasso.get().load(ikonUrl + searchArrayList.get(position).getIkon()).into(holder.ik);


       holder.linearLayout.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               opedInfo(searchArrayList.get(position).getDibuat(), searchArrayList.get(position).getJumlah(), searchArrayList.get(position).getId_komentar(),searchArrayList.get(position).getKomentar(),searchArrayList.get(position).getId_akun(),searchArrayList.get(position).getNama_admin(), searchArrayList.get(position).getCaption(), searchArrayList.get(position).getSumber(), searchArrayList.get(position).getKategori(), searchArrayList.get(position).getId(), searchArrayList.get(position).getIkon(), searchArrayList.get(position).getGambar());

           }
       });
   }

    private void opedInfo(String tanggal, String jumlah,String id_komentar, String komentar,String id_akun, String nama_admin, String caption, String sumber, String ikon, String id, String kategori, String gambar){
        Intent i = new Intent(context, MainActivity.class);
        i.putExtra("nama_admin", nama_admin);
        i.putExtra("gambar", gambar);
        i.putExtra("tanggal_dibuat", tanggal);
        i.putExtra("caption", caption);
        i.putExtra("id_komentar", id_komentar);
        i.putExtra("komentar", komentar);
        i.putExtra("sumber", sumber);
        i.putExtra("jumlah", jumlah);
        i.putExtra("kategori", kategori);
        i.putExtra("id_akun", id_akun);
        i.putExtra("ikon", ikon);
        i.putExtra("id", id);
        context.startActivity(i);
    }
   public int getItemCount(){
        return  searchArrayList.size();
   }

   public void setFilter (ArrayList<Gallery>filterList){
        searchArrayList = new ArrayList<>();
        searchArrayList.addAll(filterList);
        notifyDataSetChanged();
   }

   class SearchViewHolder extends  RecyclerView.ViewHolder{

        TextView admin, deskripsi;
        CircleImageView ik;
        LinearLayout linearLayout;

        private SearchViewHolder (View itemView){

            super( itemView );

            context = itemView.getContext();
            admin = itemView.findViewById(R.id.name_tv5);
            deskripsi = itemView.findViewById(R.id.deskripsisearch);
            ik = itemView.findViewById(R.id.profil2);
            linearLayout = itemView.findViewById(R.id.linear);

        }

   }

}
