package com.novalnvall.memeunfaedah.fragment;


import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.novalnvall.memeunfaedah.Activity.Reset_Password;
import com.novalnvall.memeunfaedah.Controller.AppController;
import com.novalnvall.memeunfaedah.R;
import com.novalnvall.memeunfaedah.Util.Server;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

import static android.app.Activity.RESULT_OK;


/**
 * A simple {@link Fragment} subclass.
 */
public class Daftar extends Fragment {
    private View view;
    private FragmentManager fragmentManager;
    private RequestQueue requestQueue;
    private Button daftar, ikon;
    private EditText user, pas, nama, deskripsi, confirm, email;
    ProgressDialog progressDialog;
    Intent intent;
    private String TAG_KEY= "profil";
    int success;
    ConnectivityManager connectivityManager;
    CircleImageView contoh;
    private TextView termof;

    private static final String TAG = Daftar.class.getSimpleName();

    private String url = Server.URL + "registerandro.php";
    Bitmap bitmap, decoded;
    private static final String TAG_SUCCESS = "success";
    private static final String TAG_MESSAGE = "message";

    int PICK_IMAGE_REQUEST=1;
    int bitmap_size = 60;
    String tag_json_obj= "json_obj_req";


    public void setFragmentManager(FragmentManager fragmentManager) {
        this.fragmentManager = fragmentManager;
    }

    public static Daftar newInstance(FragmentManager fragmentManager) {
        Daftar fragment = new Daftar();
        fragment.setFragmentManager(fragmentManager);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_daftar, container, false);
        connectivityManager = (ConnectivityManager)getActivity().getSystemService(getContext().CONNECTIVITY_SERVICE);
        {
            if(connectivityManager.getActiveNetworkInfo()!=null
                    && connectivityManager.getActiveNetworkInfo().isAvailable()
                    && connectivityManager.getActiveNetworkInfo().isConnected()){
            }else{
                Toast.makeText(getContext(), "Tak ada koneksi internet", Toast.LENGTH_SHORT).show();
            }
        }

        contoh= view.findViewById(R.id.preview);
        daftar = view.findViewById(R.id.bdaftar);
        user = view.findViewById(R.id.username);
        pas = view.findViewById(R.id.password);
        ikon = view.findViewById(R.id.uploadprofil);
        nama = view.findViewById(R.id.nick);
        confirm = view.findViewById(R.id.confirm);
        deskripsi = view.findViewById(R.id.deskripsi_kamu);
        email = view.findViewById(R.id.e_mail);
        termof = view.findViewById(R.id.tos);



        termof.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("https://unfaedah.id/kebijakan/term-of-service.html"));
                startActivity(intent);
            }
        });

        ikon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showFileChooser();
            }
        });

        daftar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = user.getText().toString();
                String password = pas.getText().toString();
                String confirm_password = confirm.getText().toString();
                String nama_admin = nama.getText().toString();
                String info = deskripsi.getText().toString();
                String email3 = email.getText().toString();
                String profil = ikon.getText().toString();

                final String email2 = email.getText().toString().trim();

                final String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

                email.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                    }

                    @Override
                    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                    }

                    @Override
                    public void afterTextChanged(Editable editable) {
                        if (email2.matches(emailPattern) && editable.length() > 0) {

                            Log.e("Success: ", String.valueOf(emailPattern));
                        }
                        else
                        {
                        }
                    }
                });
                if(connectivityManager.getActiveNetworkInfo()!=null
                        && connectivityManager.getActiveNetworkInfo().isAvailable()
                        && connectivityManager.getActiveNetworkInfo().isConnected()){
                    if( email2.matches(emailPattern)){
                        if(password.trim().length() > 4){
                            if(username.trim().length()  > 4){
                                if(nama_admin.trim().length() > 0 && info.trim().length() >0){
                                    if(password.equals(confirm_password)){
                                        checkRegister(username, password, nama_admin, info, profil, email2);
                                    }else {
                                        Toast.makeText(getContext(), "Konfirmasi password tidak sama", Toast.LENGTH_SHORT).show();
                                    }
                                }else {
                                    Toast.makeText(getContext(), "Masih ada yang kosong", Toast.LENGTH_SHORT).show();
                                }
                                /*if(nama_admin.trim().length() == 0){
                                    if(info.trim().length() == 0){
                                        if(email2.trim().length()==0){
                                            if(!password.equals(confirm_password)){
                                                Toast.makeText(getContext(), "Password baru dan konfirmasi password harus sama", Toast.LENGTH_SHORT).show();
                                            }else {
                                                checkRegister(username, password, confirm_password, nama_admin, info, profil, email2);
                                            }
                                            Toast.makeText(getContext(), "E-Mail masih kosong", Toast.LENGTH_SHORT).show();
                                        }
                                        Toast.makeText(getContext(), "Tentang kamu masih kosong", Toast.LENGTH_SHORT).show();
                                    }
                                    Toast.makeText(getContext(), "Nama Admin masih kosong", Toast.LENGTH_SHORT).show();
                                }*/

                            }else {
                                Toast.makeText(getContext(), "Username harus lebih dari 4 huruf atau angka", Toast.LENGTH_SHORT).show();
                            }
                        }else {
                            Toast.makeText(getContext(), "Password harus lebih dari 4 huruf atau angka", Toast.LENGTH_SHORT).show();
                        }
                    }else {
                        Toast.makeText(getContext(), "Format E-Mail salah!", Toast.LENGTH_SHORT).show();
                    }
                }else{
                    Toast.makeText(getContext(), "Tak ada internet", Toast.LENGTH_SHORT).show();
                }
            }
        });
        return view;
    }

    public String getStringImage(Bitmap bmp){
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, bitmap_size, baos);
        byte[] imageBytes =  baos.toByteArray();
        String encodedImage = Base64.encodeToString(imageBytes, Base64.DEFAULT);
        return  encodedImage;
    }
    private void showFileChooser(){
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"),PICK_IMAGE_REQUEST);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData()!=null){
            Uri filePath = data.getData();
            try{
                //ambil file dari gallery
                bitmap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), filePath);
                setToImageView(getResizedBitmap(bitmap, 512));


            }catch (IOException e){
                e.printStackTrace();
            }
        }
    }

    private void setToImageView(Bitmap bmp){
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, bitmap_size, bytes);
        decoded = BitmapFactory.decodeStream(new ByteArrayInputStream(bytes.toByteArray()));
        contoh.setImageBitmap(decoded);
    }

    public Bitmap getResizedBitmap (Bitmap image, int maxSize){
        int width = image.getWidth();
        int height = image.getHeight();

        float bitmapRatio = (float) width/ (float) height;
        if(bitmapRatio>3){
            width = maxSize;
            height = (int) (width/bitmapRatio);
        }else{
            height= maxSize;
            width = (int)(height*bitmapRatio);
        }
        return  Bitmap.createScaledBitmap(image, width, height, true);
    }

    private void checkRegister(final String username, final String password, final String nama_admin, final String info, final String profil, final String email2){
        progressDialog = new ProgressDialog(getContext());
        progressDialog.setCancelable(true);
        progressDialog.setMessage("Mendaftar...");
        showDialog();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.e(TAG, "Register Response: " + response.toString());
                hideDialog();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    success = jsonObject.getInt(TAG_SUCCESS);

                    if (success == 1) {
                        Toast.makeText(getContext(), jsonObject.getString(TAG_MESSAGE), Toast.LENGTH_LONG).show();
                        kosong();
                    } else {
                        Toast.makeText(getContext(), jsonObject.getString(TAG_MESSAGE), Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, "Login Error: "+error.getMessage());
                Toast.makeText(getContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams(){
                //kirim parameter ke url login
                Map<String, String> params = new HashMap<String, String>();

                if (decoded == null){
                    Snackbar.make(getActivity().findViewById(R.id.snack2),"Harus menambah foto profil", Snackbar.LENGTH_LONG).show();
                }else {
                    params.put("username", username);
                    params.put("password", password);
                    params.put("nama_admin", nama_admin);
                    params.put("info",info);
                    params.put("profil", profil);
                    params.put("email", email2);
                    params.put(TAG_KEY, getStringImage(decoded));

                }

                Log.e(TAG, ""+ params);
                return params;
            }
        };
        AppController.getInstance().addToRequestQueue(stringRequest, tag_json_obj);

    }
    private void showDialog(){
        if(!progressDialog.isShowing())
            progressDialog.show();
    }
    private void hideDialog(){
        if(progressDialog.isShowing())
            progressDialog.dismiss();
    }

        private void kosong(){
        contoh.setImageResource(0);
        nama.setText(null);
        user.setText(null);
        pas.setText(null);
        confirm.setText(null);
        deskripsi.setText(null);
        }
}
