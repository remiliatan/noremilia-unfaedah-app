package com.novalnvall.memeunfaedah.Activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.novalnvall.memeunfaedah.R;
import com.novalnvall.memeunfaedah.Util.Server;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

public class Lupa_Password extends AppCompatActivity {

    ImageView kembali;
    Button search;
    CircleImageView ik;
    TextView admin, des;
    EditText username, edit_mail;
    LinearLayout layoutLupa, layoutNothing;
    String lupaPasswordUrl = Server.URL +"lupa_password.php";

    ProgressDialog progressDialog;
    int success;
    public static final String TAG_SUCCESS = "success";

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lupa__password);

        search = findViewById(R.id.bcari);
        kembali = findViewById(R.id.back);
        username = findViewById(R.id.user);
        edit_mail = findViewById(R.id.edt_mail);
        admin = findViewById(R.id.name_tvlupa);
        ik = findViewById(R.id.profillupa);
        layoutLupa = findViewById(R.id.linearlupa2);
        des = findViewById(R.id.deskripsilupa);
        layoutNothing = findViewById(R.id.nothing);

        layoutLupa.setVisibility(View.GONE);
        layoutNothing.setVisibility(View.GONE);



        kembali.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent( Lupa_Password.this, loginregis.class);
                startActivity(intent);
            }
        });

        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String namauser = username.getText().toString();

                if(namauser.trim().length() >0){
                    cariUser(namauser);
                }else {
                    Toast.makeText(Lupa_Password.this, "Masih ada yang kosong", Toast.LENGTH_SHORT).show();
                }
            }
        });

        /*reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nama_email = edit_mail.getText().toString();

                if (nama_email.trim().length() > 0 ){
                    cariProfil(nama_email);
                }else {
                    Toast.makeText(Lupa_Password.this, "E-Mail masih kosong", Toast.LENGTH_SHORT).show();
                }
            }
        });*/
    }
/*
    private void cariProfil(final String nama_email){
        progressDialog = new ProgressDialog( this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Memproses..");
        showDialog();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, lupaPasswordUrl, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                hideDialog();

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    success = jsonObject.getInt(TAG_SUCCESS);
                    final String id_akun = jsonObject.getString("id_akun");

                    if (success == 1){

                        Intent intent = new Intent(Lupa_Password.this, GantiPassword.class);
                        intent.putExtra("id_akun", id_akun);
                        startActivity(intent);
                    }else {
                        Toast.makeText(Lupa_Password.this, "Email Salah!", Toast.LENGTH_SHORT).show();
                    }
                }catch (JSONException e){
                    e.printStackTrace();
                }

            }
        }){
            @Override
            protected Map<String, String> getParams(){
                Map<String, String> params = new HashMap<>();
                params.put("id_akun", id_akun);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }*/

    private void cariUser(final String namauser){
        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Mencari..");
        showDialog();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, lupaPasswordUrl, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
              hideDialog();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    success = jsonObject.getInt(TAG_SUCCESS);
                    if (success == 1) {

                       final String id_akun = jsonObject.getString("id_akun");
                       String nama_admin = jsonObject.getString("nama_admin");
                       String ikon = jsonObject.getString("ikon");
                       String deskripsi = jsonObject.getString("deskripsi");
                       final String email = jsonObject.getString("email");
                       Button reset = findViewById(R.id.breset);
                       final EditText mail = findViewById(R.id.edt_mail);

                        Picasso.get().load(Server.URL + ikon).into(ik);
                        admin.setText(nama_admin);
                        des.setText(deskripsi);
                        layoutNothing.setVisibility(View.GONE);
                        layoutLupa.setVisibility(View.VISIBLE);

                        reset.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                String email_user = mail.getText().toString();

                                if(email_user.trim().length() > 0){
                                    if (!email_user.equals(email)){
                                        Toast.makeText(Lupa_Password.this, "E-Mail Salah!", Toast.LENGTH_SHORT).show();

                                    }else {
                                        Intent intent = new Intent(Lupa_Password.this, Reset_Password.class);
                                        intent.putExtra("id_akun", id_akun);
                                        startActivity(intent);
                                    }
                                }else {
                                    Toast.makeText(Lupa_Password.this, "Masih ada yang kosong", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });


                    } else {
                        layoutLupa.setVisibility(View.GONE);
                        layoutNothing.setVisibility(View.VISIBLE);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Lupa_Password.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams(){
                Map<String, String> params = new HashMap<>();
                params.put("username", namauser);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(Lupa_Password.this);
        requestQueue.add(stringRequest);

    }
    private void showDialog(){
        if(!progressDialog.isShowing())
            progressDialog.show();
    }
    private void hideDialog(){
        if(progressDialog.isShowing())
            progressDialog.dismiss();
    }

    }

