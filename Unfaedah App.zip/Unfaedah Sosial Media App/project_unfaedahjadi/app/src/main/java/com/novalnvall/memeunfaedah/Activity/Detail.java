package com.novalnvall.memeunfaedah.Activity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.novalnvall.memeunfaedah.R;
import com.novalnvall.memeunfaedah.Util.Server;
import com.novalnvall.memeunfaedah.adapter.KomentarAdapter;
import com.novalnvall.memeunfaedah.fragment.Login;
import com.novalnvall.memeunfaedah.model.Gallery;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

public class Detail extends AppCompatActivity {

    private KomentarAdapter adapter;
    private RecyclerView recyclerView;
    private ArrayList<Gallery>komentarArrayList;
    private RequestQueue requestQueue;
    String nama_admin, gambar, caption, ikon, kategori, sumber, id_komentar, id, id_akun, komentar, suka2, id_admin, tanggal;
    TextView admin_tv, caption_tv, kategori_tv, sumber_tv, dibuat;
    CircleImageView ikon_admin;
    ImageView konten, lapor;
    Button kirim, komen, suka, edit;
    EditText ekomentar;
    LinearLayout linear_komen;
    AlertDialog dialog;
    private String urlHapus = Server.URL + "hapus_edit.php";
    private String urlEdit = Server.URL + "edit.php";
    private String urlLapor = Server.URL + "lapor.php";

    public final String TAG_ID  = "id_akun";
    public final String TAG_SUCCESS = "success";
    public final String Tag_MESSAGE = "message";
    public final String ikonUrl = Server.URL;
    public final String imgUrl = Server.URL;
    public final String komUrl = Server.URL + "kirim_komentar.php";
    private boolean klik =  false;
    private View dialogView, ediView;
    private static final String TAG = Detail.class.getSimpleName();
    SharedPreferences sharedPreferences;
    ProgressDialog progressDialog;
    int success;
    private String urlSuka = Server.URL +"suka.php";
    private AdView adView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail_item);


        //id dari layout
        ekomentar = findViewById(R.id.edt_komentar);
        kirim = findViewById(R.id.kirim_komentar);
        ikon_admin = findViewById(R.id.ikon2);
        konten = findViewById(R.id.img_v2);
        admin_tv = findViewById(R.id.name_tv3);
        caption_tv = findViewById(R.id.cap_tv2);
        kategori_tv = findViewById(R.id.kat_tv2);
        sumber_tv = findViewById(R.id.sumber_tv2);
        komen = findViewById(R.id.bkomen);
        suka = findViewById(R.id.suka2);
        edit = findViewById(R.id.bedit2);
        lapor = findViewById(R.id.blapor2);
        linear_komen = findViewById(R.id.komen_linear);
        dibuat = findViewById(R.id.tanggal_dibuat);
        recyclerView = findViewById(R.id.recykomen);
        recyclerView.setNestedScrollingEnabled(false);


        sharedPreferences = getSharedPreferences(Login.my_shared_preferences, Context.MODE_PRIVATE);
        id_akun =sharedPreferences.getString("id_akun", TAG_ID);

        Intent intent = getIntent();

        nama_admin = intent.getStringExtra("nama_admin");
        caption = intent.getStringExtra("caption");
        kategori = intent.getStringExtra("ikon");
        sumber = intent.getStringExtra("sumber");
        gambar = intent.getStringExtra("gambar");
        id = intent.getStringExtra("id");
        id_komentar = intent.getStringExtra("id_komentar");
        id_admin = intent.getStringExtra("id_akun");
        tanggal = intent.getStringExtra("tanggal_dibuat");
        suka2= intent.getStringExtra("suka");

        ikon = intent.getStringExtra("kategori");

        //iklan
        MobileAds.initialize(this, getResources().getString(R.string.kode_app_asli));
        adView = new AdView(this);
        adView.setAdSize(AdSize.SMART_BANNER);
        adView.setAdUnitId(getResources().getString(R.string.kode_banner_asli));
        adView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);

//adapter
        komentarArrayList = new ArrayList<>();
        adapter = new KomentarAdapter(this, komentarArrayList);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(adapter);

        loadData(id, id_akun, id_komentar);

        edit.setVisibility(View.GONE);
        lapor.setVisibility(View.VISIBLE);

        if(id_admin.equals(id_akun)){
            edit.setVisibility(View.VISIBLE);
            lapor.setVisibility(View.GONE);
        }else {
            edit.setVisibility(View.GONE);
            lapor.setVisibility(View.VISIBLE);
        }

        lapor.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("InflateParams")
            @Override
            public void onClick(View view) {
                dialog = new AlertDialog.Builder(Detail.this).create();
                LayoutInflater layoutInflater = (LayoutInflater)Detail.this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                dialogView = layoutInflater.inflate(R.layout.kirim_lapor, null);
                dialog.setView(dialogView);
                dialog.setCancelable(true);
                final Spinner alasan = dialogView.findViewById(R.id.spiner_alasan);
                final EditText keterangan = dialogView.findViewById(R.id.edt_keterangan);
                final Button laporkan = dialogView.findViewById(R.id.blaporkiriman);

                laporkan.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        final String alasan1 = alasan.getSelectedItem().toString();
                        final String ket = keterangan.getText().toString();

                        if(ket.trim().length() > 0){
                            if (alasan1.equals("-Pilih Alasan-")){
                                Toast.makeText(Detail.this, "Mohon pilih alasan", Toast.LENGTH_SHORT).show();
                            }else {
                                progressDialog = new ProgressDialog(Detail.this);
                                progressDialog.setMessage("Loading..");
                                progressDialog.setCancelable(false);
                                showDialog();

                                StringRequest stringRequest = new StringRequest(Request.Method.POST, urlLapor, new Response.Listener<String>() {
                                    @Override
                                    public void onResponse(String response) {
                                        hideDialog();

                                        try {
                                            JSONObject jsonObject = new JSONObject(response);
                                            success = jsonObject.getInt("success");

                                            if (success == 1) {
                                                Toast.makeText(Detail.this, jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
                                                dialog.dismiss();
                                            } else {
                                                Toast.makeText(Detail.this, jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
                                            }
                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                        }
                                    }
                                }, new Response.ErrorListener() {
                                    @Override
                                    public void onErrorResponse(VolleyError error) {
                                        Toast.makeText(Detail.this, error.getMessage(), Toast.LENGTH_SHORT).show();
                                    }
                                }){
                                    @Override
                                    protected Map<String, String>getParams(){
                                        Map<String, String> params = new HashMap<>();
                                        params.put("id_akun", id_akun);
                                        params.put("id", id);
                                        params.put("alasan", alasan1);
                                        params.put("keterangan", ket);
                                        return params;
                                    }
                                };
                                RequestQueue requestQueue = Volley.newRequestQueue(Detail.this);
                                requestQueue.add(stringRequest);
                            }
                        }else {
                            Toast.makeText(Detail.this, "Keterangan tidak boleh kosong", Toast.LENGTH_SHORT).show();
                        }

                    }
                });
                dialog.show();
            }
        });


        kirim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String komen = ekomentar.getText().toString();

                if(komen.trim().length() > 0 ) {
                        checkKomentar(id, id_akun, komen);
                }else {
                    Toast.makeText(Detail.this, "Masih ada yang kosong", Toast.LENGTH_SHORT).show();
                }

            }
        });



        View.OnClickListener like = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (klik){

                    suka.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.thumb_up_outline), null, null, null);
                    StringRequest stringRequest = new StringRequest(Request.Method.POST, urlSuka, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            Log.e("Tidak Suka: ", String.valueOf(response));
                            suka.setText(String.valueOf(response));


                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Log.e("Error Suka", error.toString());
                        }
                    }){
                        @Override
                        protected Map<String, String>getParams(){
                            Map<String, String> params = new HashMap<String, String>();
                            params.put("id", id);
                            params.put("id_akun", id_akun);
                            params.put("tidak_suka", suka2);
                            return  params;

                        }
                    };
                    RequestQueue requestQueue = Volley.newRequestQueue(Detail.this);
                    requestQueue.add(stringRequest);
                }else{

                    suka.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.thumb_up), null, null, null);

                    StringRequest stringRequest = new StringRequest(Request.Method.POST, urlSuka, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                            Log.e("Suka: ", String.valueOf(response));
                            suka.setText(String.valueOf(response));
                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Log.e("Error Suka", error.toString());
                        }
                    }){
                        @Override
                        protected Map<String, String>getParams(){
                            Map<String, String> params = new HashMap<String, String>();
                            params.put("id", id);
                            params.put("id_akun", id_akun);
                            params.put("suka", suka2);
                            return  params;

                        }
                    };
                    RequestQueue requestQueue = Volley.newRequestQueue(Detail.this);
                    requestQueue.add(stringRequest);

                }
                klik = !klik;
            }

        };

       
        suka.setOnClickListener(like);

        konten.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Detail.this, GambarFull.class);
                i.putExtra("nama_admin", nama_admin);
                i.putExtra("gambar", gambar);
                i.putExtra("caption", caption);
                i.putExtra("id_komentar", id_komentar);
                i.putExtra("komentar", komentar);
                i.putExtra("sumber", sumber);
                i.putExtra("tanggal_dibuat", tanggal);
                i.putExtra("kategori", kategori);
                i.putExtra("id_akun", id_admin);
                i.putExtra("ikon", ikon);
                i.putExtra("id", id);
                startActivity(i);
            }
        });



        edit.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("InflateParams")
            @Override
            public void onClick(View view) {
                dialog = new AlertDialog.Builder(Detail.this).create();
                final LayoutInflater inflater = (LayoutInflater)Detail.this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                dialogView = inflater.inflate(R.layout.edit, null);
                dialog.setView(dialogView);
                dialog.setCancelable(true);
                final TextView rubah = dialogView.findViewById(R.id.ubah);
                final TextView hapus = dialogView.findViewById(R.id.deleted);
                final TextView lapor = dialogView.findViewById(R.id.report);
                lapor.setVisibility(View.GONE);



                rubah.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        LayoutInflater inflater1 = (LayoutInflater)Detail.this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                        ediView = inflater1.inflate(R.layout.edit_postingan, null);
                        final EditText capti = ediView.findViewById(R.id.edt_caption);
                        final Button siap = ediView.findViewById(R.id.bcaption_edit);
                        final AlertDialog builder = new AlertDialog.Builder(Detail.this).create();
                        builder.setView(ediView);
                        builder.setCancelable(true);
                        capti.setText(caption);

                        siap.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                final String capt = capti.getText().toString();

                                if(capt.trim().length() > 0){
                                    progressDialog = new ProgressDialog(Detail.this);
                                    progressDialog.setCancelable(false);
                                    progressDialog.setMessage("Mengubah..");
                                    showDialog();

                                    StringRequest stringRequest = new StringRequest(Request.Method.POST, urlEdit, new Response.Listener<String>() {
                                        @Override
                                        public void onResponse(String response) {
                                            hideDialog();

                                            try {
                                                JSONObject jsonObject = new JSONObject(response);
                                                success = jsonObject.getInt("success");

                                                if (success == 1) {
                                                    dialog.dismiss();
                                                    builder.dismiss();
                                                    Toast.makeText(Detail.this, "Berhasil", Toast.LENGTH_SHORT).show();

                                                } else {
                                                    Toast.makeText(Detail.this, jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
                                                }
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                            }
                                        }
                                    }, new Response.ErrorListener() {
                                        @Override
                                        public void onErrorResponse(VolleyError error) {
                                            Toast.makeText(Detail.this, error.getMessage(), Toast.LENGTH_SHORT).show();
                                        }
                                    }){
                                        @Override
                                        protected Map<String, String>getParams(){
                                            Map<String, String>params = new HashMap<>();
                                            params.put("id", id);
                                            params.put("caption", capt);
                                            return params;
                                        }
                                    };
                                    RequestQueue requestQueue = Volley.newRequestQueue(Detail.this);
                                    requestQueue.add(stringRequest);
                                }else {
                                    Toast.makeText(Detail.this, "Caption tidak boleh kosong", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
                        builder.show();
                    }
                });
                hapus.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        final AlertDialog.Builder builder = new AlertDialog.Builder(Detail.this);
                        builder.setTitle("Hapus");
                        builder.setMessage("Yakin ingin menghapus kiriman ini?");
                        builder.setPositiveButton("Ya", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                progressDialog = new ProgressDialog(Detail.this);
                                progressDialog.setMessage("Menghapus..");
                                progressDialog.setCancelable(false);
                                showDialog();

                                StringRequest stringRequest = new StringRequest(Request.Method.POST, urlHapus, new Response.Listener<String>() {
                                    @Override
                                    public void onResponse(String response) {
                                        hideDialog();

                                        try {
                                            JSONObject jsonObject = new JSONObject(response);
                                            Log.e("RESPON HAPUS: ", String.valueOf(jsonObject));
                                            success = jsonObject.getInt("success");

                                            if (success == 1) {
                                                dialog.dismiss();
                                                Toast.makeText(Detail.this, "Berhasil menghapus", Toast.LENGTH_SHORT).show();
                                            } else {
                                                Toast.makeText(Detail.this, jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
                                            }
                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                        }
                                    }
                                }, new Response.ErrorListener() {
                                    @Override
                                    public void onErrorResponse(VolleyError error) {
                                        Toast.makeText(Detail.this, error.getMessage(), Toast.LENGTH_SHORT).show();
                                    }
                                }) {
                                    @Override
                                    protected Map<String, String> getParams() {
                                        Map<String, String> params = new HashMap<>();
                                        params.put("id", id);
                                        params.put("gambar", gambar);
                                        return params;
                                    }
                                };
                                RequestQueue requestQueue = Volley.newRequestQueue(Detail.this);
                                requestQueue.add(stringRequest);
                            }
                        });
                        builder.setNeutralButton("Tidak", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Toast.makeText(Detail.this, "Ok", Toast.LENGTH_SHORT).show();
                            }
                        });
                        builder.show();
                    }
                });
                dialog.show();
            }
        });

        admin_tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                   Intent i = new Intent(Detail.this, MainActivity.class);
                    i.putExtra("nama_admin", nama_admin);
                    i.putExtra("gambar", gambar);
                    i.putExtra("tanggal_dibuat", tanggal);
                    i.putExtra("caption", caption);
                    i.putExtra("id_komentar", id_komentar);
                    i.putExtra("komentar", komentar);
                    i.putExtra("sumber", sumber);
                    i.putExtra("kategori", kategori);
                    i.putExtra("id_akun", id_admin);
                    i.putExtra("ikon", ikon);
                    i.putExtra("id", id);
                    startActivity(i);

            }
        });

        ikon_admin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    Intent i = new Intent(Detail.this, MainActivity.class);
                    i.putExtra("nama_admin", nama_admin);
                    i.putExtra("gambar", gambar);
                    i.putExtra("caption", caption);
                    i.putExtra("id_komentar", id_komentar);
                    i.putExtra("komentar", komentar);
                    i.putExtra("tanggal_dibuat", tanggal);
                    i.putExtra("sumber", sumber);
                    i.putExtra("kategori", kategori);
                    i.putExtra("id_akun", id_admin);
                    i.putExtra("ikon", ikon);
                    i.putExtra("id", id);
                    startActivity(i);

            }
        });

    }


    private void checkKomentar (final String id, final String id_akun , final String komen){

        progressDialog = new ProgressDialog(Detail.this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Sedang mengirim...");
        showDialog();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, komUrl, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.e("Respon Komentar: ", String.valueOf(response));
                hideDialog();

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    success = jsonObject.getInt(TAG_SUCCESS);

                    if (success == 1) {
                        // doTheAutoRefresh();
                        loadData(id, id_akun, id_komentar);
                        Toast.makeText(Detail.this, jsonObject.getString(Tag_MESSAGE), Toast.LENGTH_SHORT).show();
                        kosong();

                    } else {
                        Toast.makeText(Detail.this, jsonObject.getString(Tag_MESSAGE), Toast.LENGTH_SHORT).show();

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                adapter.notifyDataSetChanged();

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG,"Respon Error: " + error.getMessage());
                Toast.makeText(Detail.this, "Ada kesalahan, mohon coba lagi", Toast.LENGTH_SHORT).show();
            }
        }){
            @Override protected Map<String, String> getParams(){
                Map<String, String> params = new HashMap<String, String>();
                params.put("komentar", komen);
                params.put("id_akun", id_akun);
                params.put("id", id);
                Log.e(TAG, ""+params);
                return params;
            }

        };

        requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }
    private void showDialog(){
        if (!progressDialog.isShowing())
            progressDialog.show();
    }
    private void hideDialog(){
        if (progressDialog.isShowing())
            progressDialog.dismiss();
    }
    private void kosong(){
        ekomentar.setText(null);
    }



    private void loadData(final String id, final String id_komentar, final String id_akun){
        final String jsonUrl = Server.URL + "list_komentar.php";

        StringRequest stringRequest = new StringRequest(Request.Method.POST, jsonUrl, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                komentarArrayList.clear();

                try {

                    JSONObject jsonObject = new JSONObject(response);
                    JSONObject objPosting = jsonObject.getJSONObject("posting");

                    Log.e("POSTINGAN", String.valueOf(objPosting));

                    caption_tv.setText(objPosting.getString("caption"));
                    admin_tv.setText(objPosting.getString("nama_admin"));
                    sumber_tv.setText(objPosting.getString("sumber"));
                    kategori_tv.setText(objPosting.getString("kategori"));
                    komen.setText(objPosting.getString("jumlah"));
                    suka.setText(objPosting.getString("suka"));
                    dibuat.setText(tanggal);

                    Picasso.get().load(ikonUrl +objPosting.getString("ikon")).into(ikon_admin);
                    Picasso.get().load(imgUrl+objPosting.getString("gambar")).into(konten);

                    JSONArray jsonArray2 = objPosting.getJSONArray("menyukai");
                    Drawable img = getResources().getDrawable(R.drawable.thumb_up_outline);
                    Drawable img1 = getResources().getDrawable(R.drawable.thumb_up);

                    for (int k = 0; k <jsonArray2.length(); k++){
                        JSONObject object = jsonArray2.getJSONObject(k);

                        final String id_penyuka = object.getString("id_penyuka");

                        SharedPreferences sharedPreferences1 = getSharedPreferences(Login.my_shared_preferences, Context.MODE_PRIVATE);
                        String id_orang = sharedPreferences1.getString("id_akun", "id_akun");

                            if(id_penyuka == null){
                                suka.setCompoundDrawablesWithIntrinsicBounds(img, null, null, null);
                                klik = false;

                            }else if(id_penyuka.equals(id_orang)){
                                suka.setCompoundDrawablesWithIntrinsicBounds(img1,null, null, null);
                                klik = true;
                            }else {
                                klik = false;
                                suka.setCompoundDrawablesWithIntrinsicBounds(img, null, null, null);

                            }

                        }


                    JSONObject jsonObject1= new JSONObject(response);
                    JSONArray jsonArray = jsonObject1.optJSONArray("komentar");

                    for(int i = 0; i < 100; i++){
                        JSONObject object = jsonArray.getJSONObject(i);
                        Log.e("KOMENTAR: ", String.valueOf(object));
                        Gallery gallery = new Gallery();

                        gallery.setId(object.getString("id"));
                        gallery.setId_akun(object.getString("id_akun"));
                        gallery.setId_komentar(object.getString("id_komentar"));
                        gallery.setIkon(object.getString("ikon"));
                        gallery.setNama_admin(object.getString("nama_admin"));
                        gallery.setKomentar(object.optString("komentar"));
                        komentarArrayList.add(gallery);

                        if (komentarArrayList.size() > 100){
                            linear_komen.setVisibility(View.GONE);
                        }
                    }



                } catch (JSONException e){
                    e.printStackTrace();
                }
                adapter.notifyDataSetChanged();

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("Volley", error.toString());
            }
        }){
           @Override
            protected Map<String, String> getParams() {
               Map<String, String> params = new HashMap<>();
               params.put("id_komentar", id_komentar);
               params.put("id", id);

               return params;
           }
           };
            requestQueue = Volley.newRequestQueue(Detail.this);
            requestQueue.add(stringRequest);
        }
}

