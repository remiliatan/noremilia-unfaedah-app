package com.novalnvall.memeunfaedah.adapter;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.novalnvall.memeunfaedah.Activity.Detail;
import com.novalnvall.memeunfaedah.Activity.GambarFull;
import com.novalnvall.memeunfaedah.R;
import com.novalnvall.memeunfaedah.Util.Server;
import com.novalnvall.memeunfaedah.fragment.Login;
import com.novalnvall.memeunfaedah.model.Gallery;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

public class ProfilAdapter extends RecyclerView.Adapter<ProfilAdapter.GalleryViewHolder> {
    private LayoutInflater inflater;
    private ArrayList<Gallery>galleryArrayList;
    private Context ctx;
    private String imgUrl=Server.URL;
    private final static String TAG_ID = "id_akun";
    private SharedPreferences sharedPreferences;
    private boolean klik = false;
    private String urlSuka = Server.URL +"suka.php";
    private String urlHapus = Server.URL + "hapus_edit.php";
    private String urlEdit = Server.URL + "edit.php";
    private String urlLapor = Server.URL+ "lapor.php";

    private String ikonUrl=Server.URL;
    private AlertDialog dialog;
    private ProgressDialog progressDialog;
    private View dialogView, ediView;
    private int success;

    public ProfilAdapter(Context ctx, ArrayList<Gallery>galleryArrayList){
        inflater =  LayoutInflater.from(ctx);
        this.ctx = ctx;
        this.galleryArrayList = galleryArrayList;
    }
    @Override
    public ProfilAdapter.GalleryViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View view = inflater.inflate(R.layout.gallery_item, parent, false);
        ProfilAdapter.GalleryViewHolder holder = new ProfilAdapter.GalleryViewHolder(view);
        return holder;
    }
    @Override
    public void onBindViewHolder(final ProfilAdapter.GalleryViewHolder holder, final int position){

                holder.admin.setText(galleryArrayList.get(position).getNama_admin());
                holder.caption.setText(galleryArrayList.get(position).getCaption());
                holder.sumber.setText(galleryArrayList.get(position).getSumber());
                holder.kategori.setText(galleryArrayList.get(position).getKategori());
                holder.dibuat.setText(galleryArrayList.get(position).getDibuat());
                Picasso.get().load(imgUrl + galleryArrayList.get(position).getGambar()).into(holder.iv);
                Picasso.get().load(ikonUrl + galleryArrayList.get(position).getIkon()).into(holder.ik);

                holder.like.setText(galleryArrayList.get(position).getSuka());
                holder.komen.setText(galleryArrayList.get(position).getJumlah());

                holder.komen.setTag(position);



                holder.komen.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        int pos = (int) view.getTag();

                        final String nama_admin = galleryArrayList.get(position).getNama_admin();
                        final String gambar = galleryArrayList.get(position).getGambar();
                        final String caption = galleryArrayList.get(position).getCaption();
                        final String id_komentar = galleryArrayList.get(position).getId_komentar();
                        final String komentar = galleryArrayList.get(position).getKomentar();
                        final String sumber = galleryArrayList.get(position).getSumber();
                        final String suka = galleryArrayList.get(position).getSuka();
                        final String kategori = galleryArrayList.get(position).getKategori();
                        final String dibuat = galleryArrayList.get(position).getDibuat();
                        final String id_akun = galleryArrayList.get(position).getId_akun();
                        final String ikon = galleryArrayList.get(position).getIkon();
                        final String id = galleryArrayList.get(position).getId();


                        Intent i = new Intent(ctx, Detail.class);
                        i.putExtra("nama_admin", nama_admin);
                        i.putExtra("gambar", gambar);
                        i.putExtra("tanggal_dibuat", dibuat);
                        i.putExtra("caption", caption);
                        i.putExtra("suka", suka);
                        i.putExtra("id_komentar", id_komentar);
                        i.putExtra("komentar", komentar);
                        i.putExtra("sumber", sumber);
                        i.putExtra("kategori", kategori);
                        i.putExtra("id_akun", id_akun);
                        i.putExtra("ikon", ikon);
                        i.putExtra("id", id);
                        ctx.startActivity(i);


                /*        openDetailActivity  (galleryArrayList.get(position).getId_komentar(),galleryArrayList.get(position  ).getKomentar(),galleryArrayList.get(position ).getId_akun(),galleryArrayList.get(position ).getNama_admin(), galleryArrayList.get(position ).getCaption(), galleryArrayList.get(position ).getSumber(), galleryArrayList.get(position ).getKategori(), galleryArrayList.get(position ).getId(), galleryArrayList.get(position ).getIkon(), galleryArrayList.get(position ).getGambar());
                */    }
                });


        final String id = galleryArrayList.get(position).getId();
        final String id_akun = galleryArrayList.get(position).getId_akun();
        final String suka2 = galleryArrayList.get(position).getSuka();
        final String caption = galleryArrayList.get(position).getCaption();
        final String id_penyuka = galleryArrayList.get(position).getPenyuka();
        final String gambar = galleryArrayList.get(position).getGambar();


        holder.edit.setVisibility(View.GONE);
        holder.lapor.setVisibility(View.VISIBLE);
        sharedPreferences = ctx.getSharedPreferences(Login.my_shared_preferences, Context.MODE_PRIVATE);
        final String id_admin = sharedPreferences.getString("id_akun", TAG_ID);

        if(id_akun.equals(id_admin)){
            holder.edit.setVisibility(View.VISIBLE);
            holder.lapor.setVisibility(View.GONE);
        }else {
            holder.edit.setVisibility(View.GONE);
            holder.lapor.setVisibility(View.VISIBLE);
        }

        holder.iv.getTag(position);
        holder.iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDetailActivity3(galleryArrayList.get(position).getDibuat(), galleryArrayList.get(position).getSuka(), galleryArrayList.get(position).getJumlah(), galleryArrayList.get(position).getId_komentar(), galleryArrayList.get(position).getKomentar(), galleryArrayList.get(position).getId_akun(), galleryArrayList.get(position).getNama_admin(), galleryArrayList.get(position).getCaption(), galleryArrayList.get(position).getSumber(), galleryArrayList.get(position).getKategori(), galleryArrayList.get(position).getId(), galleryArrayList.get(position).getIkon(), galleryArrayList.get(position).getGambar());

            }
        });

        holder.lapor.setTag(position);
        holder.lapor.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("InflateParams")
            @Override
            public void onClick(View view) {
                dialog = new AlertDialog.Builder(ctx).create();
                LayoutInflater layoutInflater = (LayoutInflater)ctx.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                dialogView = layoutInflater.inflate(R.layout.kirim_lapor, null);
                dialog.setView(dialogView);
                dialog.setCancelable(true);
                final Spinner alasan = dialogView.findViewById(R.id.spiner_alasan);
                final EditText keterangan = dialogView.findViewById(R.id.edt_keterangan);
                final Button laporkan = dialogView.findViewById(R.id.blaporkiriman);

                laporkan.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        final String alasan1 = alasan.getSelectedItem().toString();
                        final String ket = keterangan.getText().toString();

                        if(ket.trim().length() > 0){
                            if (alasan1.equals("-Pilih Alasan-")){
                                Toast.makeText(ctx, "Mohon pilih alasan", Toast.LENGTH_SHORT).show();
                            }else {
                                progressDialog = new ProgressDialog(ctx);
                                progressDialog.setMessage("Loading..");
                                progressDialog.setCancelable(false);
                                showDialog();

                                StringRequest stringRequest = new StringRequest(Request.Method.POST, urlLapor, new Response.Listener<String>() {
                                    @Override
                                    public void onResponse(String response) {
                                        hideDialog();

                                        try {
                                            JSONObject jsonObject = new JSONObject(response);
                                            success = jsonObject.getInt("success");

                                            if (success == 1) {
                                                Toast.makeText(ctx, jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
                                                dialog.dismiss();
                                            } else {
                                                Toast.makeText(ctx, jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
                                            }
                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                        }
                                    }
                                }, new Response.ErrorListener() {
                                    @Override
                                    public void onErrorResponse(VolleyError error) {
                                        Toast.makeText(ctx, error.getMessage(), Toast.LENGTH_SHORT).show();
                                    }
                                }){
                                    @Override
                                    protected Map<String, String>getParams(){
                                        Map<String, String> params = new HashMap<>();
                                        params.put("id_akun", id_admin);
                                        params.put("id", id);
                                        params.put("alasan", alasan1);
                                        params.put("keterangan", ket);
                                        return params;
                                    }
                                };
                                RequestQueue requestQueue = Volley.newRequestQueue(ctx);
                                requestQueue.add(stringRequest);
                            }
                        }else {
                            Toast.makeText(ctx, "Keterangan tidak boleh kosong", Toast.LENGTH_SHORT).show();
                        }

                    }
                });
                dialog.show();
            }
        });


        holder.edit.setTag(position);
        holder.edit.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("InflateParams")
            @Override
            public void onClick(View view) {
                final String id_hapus = galleryArrayList.get(position).getId();
                dialog = new AlertDialog.Builder(ctx).create();
                final LayoutInflater inflater = (LayoutInflater)ctx.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                dialogView = inflater.inflate(R.layout.edit, null);
                dialog.setView(dialogView);
                dialog.setCancelable(true);
                final TextView rubah = dialogView.findViewById(R.id.ubah);
                final TextView hapus = dialogView.findViewById(R.id.deleted);
                final TextView lapor = dialogView.findViewById(R.id.report);
                lapor.setVisibility(View.GONE);


                rubah.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        LayoutInflater inflater1 = (LayoutInflater)ctx.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                        ediView = inflater1.inflate(R.layout.edit_postingan, null);
                        final EditText capti = ediView.findViewById(R.id.edt_caption);
                        final Button siap = ediView.findViewById(R.id.bcaption_edit);
                        final AlertDialog builder = new AlertDialog.Builder(ctx).create();
                        builder.setView(ediView);
                        builder.setCancelable(true);
                        capti.setText(caption);

                        siap.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                final String capt = capti.getText().toString();

                                if(capt.trim().length() > 0){
                                    progressDialog = new ProgressDialog(ctx);
                                    progressDialog.setCancelable(false);
                                    progressDialog.setMessage("Mengubah..");
                                    showDialog();

                                    StringRequest stringRequest = new StringRequest(Request.Method.POST, urlEdit, new Response.Listener<String>() {
                                        @Override
                                        public void onResponse(String response) {
                                            hideDialog();

                                            try {
                                                JSONObject jsonObject = new JSONObject(response);
                                                success = jsonObject.getInt("success");

                                                if (success == 1) {
                                                    dialog.dismiss();
                                                    builder.dismiss();
                                                    Toast.makeText(ctx, "Berhasil", Toast.LENGTH_SHORT).show();

                                                } else {
                                                    Toast.makeText(ctx, jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
                                                }
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                            }
                                        }
                                    }, new Response.ErrorListener() {
                                        @Override
                                        public void onErrorResponse(VolleyError error) {
                                            Toast.makeText(ctx, error.getMessage(), Toast.LENGTH_SHORT).show();
                                        }
                                    }){
                                        @Override
                                        protected Map<String, String>getParams(){
                                            Map<String, String>params = new HashMap<>();
                                            params.put("id", id);
                                            params.put("caption", capt);
                                            return params;
                                        }
                                    };
                                    RequestQueue requestQueue = Volley.newRequestQueue(ctx);
                                    requestQueue.add(stringRequest);
                                }else {
                                    Toast.makeText(ctx, "Caption tidak boleh kosong", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
                        builder.show();
                    }
                });
                hapus.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        final String id_hapus = galleryArrayList.get(position).getId();
                        final AlertDialog.Builder builder = new AlertDialog.Builder(ctx);
                        builder.setTitle("Hapus");
                        builder.setMessage("Yakin ingin menghapus kiriman ini?");
                        builder.setPositiveButton("Ya", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                progressDialog = new ProgressDialog(ctx);
                                progressDialog.setMessage("Menghapus..");
                                progressDialog.setCancelable(false);
                                showDialog();

                                StringRequest stringRequest = new StringRequest(Request.Method.POST, urlHapus, new Response.Listener<String>() {
                                    @Override
                                    public void onResponse(String response) {
                                        hideDialog();

                                        try {
                                            JSONObject jsonObject = new JSONObject(response);
                                            Log.e("RESPON HAPUS: ", String.valueOf(jsonObject));
                                            success = jsonObject.getInt("success");

                                            if (success == 1) {
                                                dialog.dismiss();
                                                Toast.makeText(ctx, "Berhasil menghapus", Toast.LENGTH_SHORT).show();
                                            } else {
                                                Toast.makeText(ctx, jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
                                            }
                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                        }
                                    }
                                }, new Response.ErrorListener() {
                                    @Override
                                    public void onErrorResponse(VolleyError error) {
                                        Toast.makeText(ctx, error.getMessage(), Toast.LENGTH_SHORT).show();
                                    }
                                }) {
                                    @Override
                                    protected Map<String, String> getParams() {
                                        Map<String, String> params = new HashMap<>();
                                        params.put("id", id);
                                        params.put("gambar", gambar);
                                        return params;
                                    }
                                };
                                RequestQueue requestQueue = Volley.newRequestQueue(ctx);
                                requestQueue.add(stringRequest);
                            }
                        });
                        builder.setNeutralButton("Tidak", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Toast.makeText(ctx, "Ok", Toast.LENGTH_SHORT).show();
                            }
                        });
                        builder.show();
                    }
                });
                dialog.show();
            }
        });




        holder.like.setTag(position);

        final boolean[] klik = {galleryArrayList.get(position).isKlik()};
        final View.OnClickListener suka = new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if (klik[0]) {

                    holder.like.setCompoundDrawablesWithIntrinsicBounds(ctx.getResources().getDrawable(R.drawable.thumb_up_outline), null, null, null);
                    StringRequest stringRequest = new StringRequest(Request.Method.POST, urlSuka, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            Log.e("Tidak Suka: ", String.valueOf(response));
                            holder.like.setText(String.valueOf(response));

                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Log.e("Error Suka", error.toString());
                        }
                    }) {
                        @Override
                        protected Map<String, String> getParams() {
                            Map<String, String> params = new HashMap<String, String>();
                            params.put("id", id);
                            params.put("id_akun", id_admin);
                            params.put("tidak_suka", suka2);
                            return params;

                        }
                    };
                    RequestQueue requestQueue = Volley.newRequestQueue(ctx);
                    requestQueue.add(stringRequest);
                } else{

                    holder.like.setCompoundDrawablesWithIntrinsicBounds(ctx.getResources().getDrawable(R.drawable.thumb_up), null, null, null);

                    StringRequest stringRequest = new StringRequest(Request.Method.POST, urlSuka, new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                            Log.e("Suka: ", String.valueOf(response));
                            holder.like.setText(String.valueOf(response));

                        }
                    }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Log.e("Error Suka", error.toString());
                        }
                    }) {
                        @Override
                        protected Map<String, String> getParams() {
                            Map<String, String> params = new HashMap<String, String>();
                            params.put("id", id);
                            params.put("id_akun", id_admin);
                            params.put("suka", suka2);
                            return params;

                        }
                    };
                    RequestQueue requestQueue = Volley.newRequestQueue(ctx);
                    requestQueue.add(stringRequest);

                }
                klik[0] = !klik[0];
            }
        };


        holder.like.setOnClickListener(suka);

        Drawable img = ctx.getResources().getDrawable(R.drawable.thumb_up_outline);

        Drawable img1 = ctx.getResources().getDrawable(R.drawable.thumb_up);
        if (id_penyuka == null) {
            holder.like.setCompoundDrawablesWithIntrinsicBounds(img, null, null, null);
        } else if (id_penyuka.equals(id_admin)) {
            holder.like.setCompoundDrawablesWithIntrinsicBounds(img1, null, null, null);
            klik[0] = true;
        } else {
            holder.like.setCompoundDrawablesWithIntrinsicBounds(img, null, null, null);

        }
    }




    @Override
    public int getItemCount(){
        return galleryArrayList.size();

    }
    private void showDialog(){
        if (!progressDialog.isShowing())
            progressDialog.show();
    }
    private void hideDialog(){
        if (progressDialog.isShowing())
            progressDialog.dismiss();
    }
    private void openDetailActivity3(String dibuat, String suka, String jumlah, String id_komentar, String komentar, String id_akun, String nama_admin, String caption, String sumber, String ikon, String id, String kategori, String gambar) {
        Intent i = new Intent(ctx, GambarFull.class);
        i.putExtra("nama_admin", nama_admin);
        i.putExtra("gambar", gambar);
        i.putExtra("caption", caption);
        i.putExtra("tanggal_dibuat", dibuat);
        i.putExtra("suka", suka);
        i.putExtra("id_komentar", id_komentar);
        i.putExtra("komentar", komentar);
        i.putExtra("sumber", sumber);
        i.putExtra("jumlah", jumlah);
        i.putExtra("kategori", kategori);
        i.putExtra("id_akun", id_akun);
        i.putExtra("ikon", ikon);
        i.putExtra("id", id);
        ctx.startActivity(i);
    }
  /*  private void openDetailActivity( String id_komentar, String komentar, String id_akun, String nama_admin, String caption, String sumber, String ikon,  String id,  String kategori, String gambar){
        Intent i = new Intent(ctx, Detail.class);
        i.putExtra("nama_admin", nama_admin);
        i.putExtra("gambar", gambar);
        i.putExtra("caption", caption);
        i.putExtra("id_komentar", id_komentar);
        i.putExtra("komentar", komentar);
        i.putExtra("sumber", sumber);
        i.putExtra("kategori", kategori);
        i.putExtra("id_akun", id_akun);
        i.putExtra("ikon", ikon);
        i.putExtra("id", id);
        ctx.startActivity(i);
    }*/



    class GalleryViewHolder extends RecyclerView.ViewHolder{
        TextView admin, caption, sumber, kategori, dibuat;
        ImageView iv;
        Button komen, like, edit;
        CircleImageView ik;
        ImageView lapor;
        Context context;

        public GalleryViewHolder(View itemView){
            super(itemView);

            context = itemView.getContext();
            admin = itemView.findViewById(R.id.name_tv);
            caption = itemView.findViewById(R.id.cap_tv);
            sumber = itemView.findViewById(R.id.sumber_tv);
            iv = itemView.findViewById(R.id.img_v);
            ik = itemView.findViewById(R.id.ikon);
            like = itemView.findViewById(R.id.suka);
            edit = itemView.findViewById(R.id.bedit);
            komen = itemView.findViewById(R.id.bkomentar);
            kategori = itemView.findViewById(R.id.kat_tv);
            lapor = itemView.findViewById(R.id.blapor);
            dibuat = itemView.findViewById(R.id.tanggal_dibuat);
        }
    }
}
