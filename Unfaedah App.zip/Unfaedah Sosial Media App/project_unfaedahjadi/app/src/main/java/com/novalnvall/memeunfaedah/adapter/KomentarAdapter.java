package com.novalnvall.memeunfaedah.adapter;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.novalnvall.memeunfaedah.Activity.MainActivity;
import com.novalnvall.memeunfaedah.R;
import com.novalnvall.memeunfaedah.Util.Server;
import com.novalnvall.memeunfaedah.fragment.Login;
import com.novalnvall.memeunfaedah.model.Gallery;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

public class KomentarAdapter extends RecyclerView.Adapter<KomentarAdapter.KomentarViewHolder> {

    private LayoutInflater inflater;
    private ArrayList<Gallery>komentarArrayList;
    private String ikonUrl = Server.URL;
    private Context context;
    private SharedPreferences sharedPreferences;
    private int success;
    private AlertDialog dialog, dialog1;
    private ProgressDialog progressDialog;
    private View dialogView, ediView;
    private String urlHapus = Server.URL + "hapus_komentar.php";
    private String urlEdit = Server.URL + "edit_komentar.php";
    private String urlLaporKomentar = Server.URL + "lapor_komentar.php";

    private static final String TAG_ID = "id_akun";

    public KomentarAdapter (Context context, ArrayList<Gallery>komentarArrayList){
        inflater = LayoutInflater.from(context);
        this.komentarArrayList = komentarArrayList;
        this.context = context;
    }
    @Override
    public KomentarAdapter.KomentarViewHolder onCreateViewHolder (ViewGroup parent, int viewType){
        View view = inflater.inflate(R.layout.komentar, parent, false);
        KomentarViewHolder holder = new KomentarViewHolder(view);

        return holder;
    }
    @Override
    public void onBindViewHolder (final KomentarViewHolder holder, final int position){

        holder.admin.setText(komentarArrayList.get(position).getNama_admin());
        holder.komen.setText(komentarArrayList.get(position).getKomentar());

        Picasso.get().load(ikonUrl +komentarArrayList.get(position).getIkon()).into(holder.ik);


        sharedPreferences = context.getSharedPreferences(Login.my_shared_preferences, Context.MODE_PRIVATE);
        final String id_admin = sharedPreferences.getString("id_akun", TAG_ID);

        final String id_akun = komentarArrayList.get(position).getId_akun();
        final String id_komentar = komentarArrayList.get(position).getId_komentar();
        final String komentar = komentarArrayList.get(position).getKomentar();


        holder.linearLayout.setTag(position);
        holder.linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(context, "Klik lama untuk aksi", Toast.LENGTH_SHORT).show();
            }
        });
        holder.linearLayout.setOnLongClickListener(new View.OnLongClickListener() {
            @SuppressLint("InflateParams")
            @Override
            public boolean onLongClick(View view) {
                if(id_akun.equals(id_admin)){
                    dialog = new AlertDialog.Builder(context).create();
                    final LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                    dialogView = inflater.inflate(R.layout.edit, null);
                    dialog.setCancelable(true);
                    dialog.setView(dialogView);

                    final TextView rubah = dialogView.findViewById(R.id.ubah);
                    final TextView hapus = dialogView.findViewById(R.id.deleted);
                    final TextView lapor = dialogView.findViewById(R.id.report);
                    lapor.setVisibility(View.GONE);

                    rubah.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            dialog1 = new AlertDialog.Builder(context).create();
                            LayoutInflater inflater1 = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                            dialogView = inflater1.inflate(R.layout.edit_postingan, null);
                            dialog1.setView(dialogView);
                            dialog1.setCancelable(true);

                            final EditText ubah = dialogView.findViewById(R.id.edt_caption);
                            final Button kirim = dialogView.findViewById(R.id.bcaption_edit);

                            ubah.setText(komentar);

                            kirim.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    final String komentar = ubah.getText().toString();

                                    if(komentar.trim().length() > 0 ){
                                        progressDialog = new ProgressDialog(context);
                                        progressDialog.setMessage("Mengubah..");
                                        progressDialog.setCancelable(false);
                                        showDialog();

                                        StringRequest stringRequest = new StringRequest(Request.Method.POST, urlEdit, new Response.Listener<String>() {
                                            @Override
                                            public void onResponse(String response) {
                                                hideDialog();

                                                try {
                                                    JSONObject jsonObject = new JSONObject(response);
                                                    success = jsonObject.getInt("success");

                                                    if (success == 1) {
                                                        dialog.dismiss();
                                                        dialog1.dismiss();
                                                        Toast.makeText(context, jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
                                                    } else {
                                                        Toast.makeText(context, jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
                                                    }
                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                }
                                            }
                                        }, new Response.ErrorListener() {
                                            @Override
                                            public void onErrorResponse(VolleyError error) {
                                                Toast.makeText(context, error.getMessage(), Toast.LENGTH_SHORT).show();
                                            }
                                        }){
                                            @Override
                                            protected Map<String, String>getParams(){
                                                Map<String, String> params = new HashMap<>();
                                                params.put("komentar", komentar);
                                                params.put("id_komentar", id_komentar);
                                                return params;
                                            }
                                        };
                                        RequestQueue requestQueue = Volley.newRequestQueue(context);
                                        requestQueue.add(stringRequest);
                                    }else {
                                        Toast.makeText(context, "Masih ada kolom kosong", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });
                            dialog1.show();
                        }
                    });

                    hapus.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            AlertDialog.Builder builder = new AlertDialog.Builder(context);
                            builder.setTitle("Hapus");
                            builder.setMessage("Hapus komentar kamu?");
                            builder.setPositiveButton("Ya", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    progressDialog = new ProgressDialog(context);
                                    progressDialog.setCancelable(false);
                                    progressDialog.setMessage("Menghapus..");
                                    showDialog();

                                    StringRequest stringRequest = new StringRequest(Request.Method.POST, urlHapus, new Response.Listener<String>() {
                                        @Override
                                        public void onResponse(String response) {
                                            hideDialog();

                                            try {
                                                JSONObject jsonObject = new JSONObject(response);
                                                success = jsonObject.getInt("success");

                                                if (success == 1) {
                                                    dialog.dismiss();
                                                    Toast.makeText(context, jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
                                                } else {
                                                    Toast.makeText(context, "Gagal", Toast.LENGTH_SHORT).show();
                                                }
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                            }
                                        }
                                    }, new Response.ErrorListener() {
                                        @Override
                                        public void onErrorResponse(VolleyError error) {
                                            Toast.makeText(context, error.getMessage(), Toast.LENGTH_SHORT).show();
                                        }
                                    }){
                                        @Override
                                        protected Map<String, String>getParams(){
                                            Map<String, String>params = new HashMap<>();
                                            params.put("id_komentar", id_komentar);
                                            return params;
                                        }
                                    };
                                    RequestQueue requestQueue = Volley.newRequestQueue(context);
                                    requestQueue.add(stringRequest);
                                }
                            });
                            builder.setNeutralButton("Batal", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    dialog.dismiss();
                                }
                            });
                            builder.show();
                        }

                    });

                    dialog.show();
                }else{
                    dialog = new AlertDialog.Builder(context).create();
                    dialog.setCancelable(true);
                    final LayoutInflater inflater1 = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                    dialogView = inflater1.inflate(R.layout.edit, null);
                    dialog.setView(dialogView);
                    final TextView lapor = dialogView.findViewById(R.id.report);
                    final TextView hapus = dialogView.findViewById(R.id.deleted);
                    final TextView edit = dialogView.findViewById(R.id.ubah);

                    lapor.setVisibility(View.VISIBLE);
                    hapus.setVisibility(View.GONE);
                    edit.setVisibility(View.GONE);

                    lapor.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            final AlertDialog dialog2 = new AlertDialog.Builder(context).create();
                            dialog2.setCancelable(true);
                            final LayoutInflater layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                            dialogView = layoutInflater.inflate(R.layout.kirim_lapor, null);
                            dialog2.setView(dialogView);
                            final Spinner alasan = dialogView.findViewById(R.id.spiner_alasan);
                            final EditText keterangan = dialogView.findViewById(R.id.edt_keterangan);
                            final Button lapor1 = dialogView.findViewById(R.id.blaporkiriman);

                            lapor1.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    final String alasan_lapor = alasan.getSelectedItem().toString();
                                    final String ket = keterangan.getText().toString();

                                    if(alasan_lapor.equals("-Pilih Alasan-")){

                                        Toast.makeText(context, "Mohon Pilih Alasan", Toast.LENGTH_SHORT).show();

                                    }else if(ket.trim().length() == 0){

                                        Toast.makeText(context, "Keterangan tidak boleh kosong", Toast.LENGTH_SHORT).show();

                                    }else{

                                        progressDialog = new ProgressDialog(context);
                                        progressDialog.setCancelable(false);
                                        progressDialog.setMessage("Melaporkan..");
                                        showDialog();

                                        StringRequest stringRequest = new StringRequest(Request.Method.POST, urlLaporKomentar, new Response.Listener<String>() {
                                            @Override
                                            public void onResponse(String response) {
                                                hideDialog();

                                              try {


                                                JSONObject jsonObject = new JSONObject(response);
                                                success = jsonObject.getInt("success");

                                                if (success == 1) {
                                                    Toast.makeText(context, jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
                                                    dialog.dismiss();
                                                    dialog2.dismiss();
                                                } else {
                                                    Toast.makeText(context, jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
                                                }
                                              }catch (JSONException e){
                                                  e.printStackTrace();
                                              }
                                            }
                                        }, new Response.ErrorListener() {
                                            @Override
                                            public void onErrorResponse(VolleyError error) {
                                                Toast.makeText(context, error.getMessage(), Toast.LENGTH_SHORT).show();
                                            }
                                        }){
                                            @Override
                                            protected Map<String, String>getParams(){
                                                Map<String, String> params = new HashMap<>();
                                                params.put("id_pelapor", id_admin);
                                                params.put("id_komentar", id_komentar);
                                                params.put("alasan", alasan_lapor);
                                                params.put("keterangan", ket);
                                                return params;
                                            }
                                        };
                                        RequestQueue requestQueue = Volley.newRequestQueue(context);
                                        requestQueue.add(stringRequest);
                                    }
                                }
                            });

                            dialog2.show();
                        }
                    });

                    dialog.show();
                }
                return false;
            }
        });


        holder.admin.setTag(position);
        holder.admin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos = (int) view.getTag();
                openDetailActivity2  (komentarArrayList.get(position).getDibuat(), komentarArrayList.get(position).getId_komentar(),komentarArrayList.get(position).getKomentar(),komentarArrayList.get(position).getId_akun(),komentarArrayList.get(position).getNama_admin(), komentarArrayList.get(position).getCaption(), komentarArrayList.get(position).getSumber(), komentarArrayList.get(position).getKategori(), komentarArrayList.get(position).getId(), komentarArrayList.get(position).getIkon(), komentarArrayList.get(position).getGambar());

            }
        });


    }
    private void openDetailActivity2(String tanggal, String id_komentar, String komentar,String id_akun, String nama_admin, String caption, String sumber, String ikon, String id, String kategori, String gambar){
        Intent i = new Intent(context, MainActivity.class);
        i.putExtra("nama_admin", nama_admin);
        i.putExtra("gambar", gambar);
        i.putExtra("tanggal_dibuat", tanggal);
        i.putExtra("caption", caption);
        i.putExtra("id_komentar", id_komentar);
        i.putExtra("komentar", komentar);
        i.putExtra("sumber", sumber);
        i.putExtra("kategori", kategori);
        i.putExtra("id_akun", id_akun);
        i.putExtra("ikon", ikon);
        i.putExtra("id", id);
        context.startActivity(i);
    }
    @Override
    public int getItemCount(){
        return komentarArrayList.size();
    }
    private void showDialog(){
        if (!progressDialog.isShowing())
            progressDialog.show();
    }
    private void hideDialog(){
        if (progressDialog.isShowing())
            progressDialog.dismiss();
    }
    class KomentarViewHolder extends RecyclerView.ViewHolder{

        TextView admin, komen;
        CircleImageView ik;
        LinearLayout linearLayout;

        public KomentarViewHolder (View itemView){
            super(itemView);

            admin = itemView.findViewById(R.id.name_komentar);
            komen = itemView.findViewById(R.id.komentar);
            ik = itemView.findViewById(R.id.ikon_komentar);
            linearLayout = itemView.findViewById(R.id.linearkomen);
        }

    }
}
