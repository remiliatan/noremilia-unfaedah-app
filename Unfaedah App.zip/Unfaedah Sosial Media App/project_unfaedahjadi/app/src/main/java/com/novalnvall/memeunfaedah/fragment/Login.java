package com.novalnvall.memeunfaedah.fragment;


import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.novalnvall.memeunfaedah.Controller.AppController;
import com.novalnvall.memeunfaedah.Activity.GalleryActivity;
import com.novalnvall.memeunfaedah.Activity.Lupa_Password;
import com.novalnvall.memeunfaedah.R;
import com.novalnvall.memeunfaedah.Util.Server;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;


/**
 * A simple {@link Fragment} subclass.
 */
public class Login extends Fragment {
    private View view;
    private FragmentManager fragmentManager;
    private RequestQueue requestQueue;
    private Button login;
    private EditText user, pas;
    private ProgressDialog progressDialog;
    private TextView forget;
    Intent intent;
    int success;
    ConnectivityManager connectivityManager;

    private String url = Server.URL + "loginandro.php";
    private static final String TAG = Login.class.getSimpleName();
    private static final String TAG_SUCCESS = "success";
    private static final String TAG_MESSAGE = "message";

    public final static  String TAG_USERNAME = "username";
    public final static String TAG_ID = "id_akun";
    public final static String TAG_ADMIN = "nama_admin";
    public final static String TAG_PROFIL = "ikon";

    public final static String TAG_DESKRIPSI = "deskripsi";



    SharedPreferences sharedPreferences;
    String id_akun, password, username, nama_admin, ikon, deskripsi, email;
    public static final String my_shared_preferences = "my_shared_preferences";
    public static final String session_status = "session_status";

    Boolean session = false;
    String tag_json_obj = "json_obj_req";



    public void setFragmentManager(FragmentManager fragmentManager) {
        this.fragmentManager = fragmentManager;
    }

    public static Login newInstance(FragmentManager fragmentManager) {
        Login fragment = new Login();
        fragment.setFragmentManager(fragmentManager);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
       view = inflater.inflate(R.layout.fragment_login, container, false);

       login = view.findViewById(R.id.blogin);
       user = view.findViewById(R.id.username);
       pas = view.findViewById(R.id.password);
        forget = view.findViewById(R.id.lupa);


       connectivityManager = (ConnectivityManager)this.getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
        {
            if (connectivityManager.getActiveNetworkInfo()!=null
                    && connectivityManager.getActiveNetworkInfo().isAvailable()
                    && connectivityManager.getActiveNetworkInfo().isConnected()){
                }else {
                Toast.makeText(getContext(), "No Internet Connection", Toast.LENGTH_SHORT).show();
            }
        }

        sharedPreferences = this.getActivity().getSharedPreferences(my_shared_preferences, Context.MODE_PRIVATE);
        session = sharedPreferences.getBoolean(session_status, false);
        id_akun = sharedPreferences.getString(TAG_ID, null);
        username = sharedPreferences.getString(TAG_USERNAME, null);
        nama_admin = sharedPreferences.getString(TAG_ADMIN, null);
        password = sharedPreferences.getString("password", null);
        ikon = sharedPreferences.getString(TAG_PROFIL, null);
        email = sharedPreferences.getString("email", email);
        deskripsi = sharedPreferences.getString(TAG_DESKRIPSI, null);
        Log.e("GAMBAR: ", String.valueOf(ikon));


        if(session){
            Intent intent = new Intent(getActivity(), GalleryActivity.class);
            intent.putExtra(TAG_ID, id_akun);
            intent.putExtra(TAG_USERNAME, username);
            intent.putExtra(TAG_PROFIL, ikon);
            intent.putExtra("email", email);
            intent.putExtra("password", password);
            intent.putExtra(TAG_DESKRIPSI, deskripsi);
            intent.putExtra(TAG_ADMIN, nama_admin);
            getActivity().finish();
            startActivity(intent);
        }

       login.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               String username = user.getText().toString();
               String password = pas.getText().toString();

               //cek kolom kosong
               if(username.trim().length() > 0 && password.trim().length() > 0) {
                   if (connectivityManager.getActiveNetworkInfo() != null
                           && connectivityManager.getActiveNetworkInfo().isAvailable()
                           && connectivityManager.getActiveNetworkInfo().isConnected()) {
                       checkLogin(username, password, nama_admin, ikon, deskripsi);
                   } else {
                       Toast.makeText(getActivity().getApplicationContext(), "Tidak Ada Koneksi", Toast.LENGTH_SHORT).show();

                   }
               }else {
                   Toast.makeText(getActivity().getApplicationContext(), "Masih ada yang kosong!", Toast.LENGTH_SHORT).show();
               }
           }
       });

       forget.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               Intent intent = new Intent(getContext(), Lupa_Password.class);
               startActivity(intent);
           }
       });

        return view;

    }
    private void checkLogin(final String username, final String password, final String nama_admin, final String ikon, final String deskripsi){
        progressDialog = new ProgressDialog(getActivity());
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Sedang Login ...");
        showDialog();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                hideDialog();

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    success = jsonObject.getInt(TAG_SUCCESS);

                    if (success == 1) {

                        String username = jsonObject.getString(TAG_USERNAME);
                        String id_akun = jsonObject.getString(TAG_ID);
                        String nama_admin =jsonObject.getString(TAG_ADMIN);
                        String ikon = jsonObject.getString(TAG_PROFIL);
                        String deskripsi = jsonObject.getString(TAG_DESKRIPSI);
                        String password = jsonObject.getString("password");
                        String email = jsonObject.getString("email");


                        Toast.makeText(getActivity().getApplicationContext(), jsonObject.getString(TAG_MESSAGE), Toast.LENGTH_SHORT).show();
                         //simpan session
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.putBoolean(session_status, true);
                        editor.putString(TAG_ID, id_akun);
                        editor.putString(TAG_PROFIL, ikon);
                        editor.putString(TAG_ADMIN, nama_admin);
                        editor.putString("password", password);
                        editor.putString(TAG_USERNAME, username);
                        editor.putString(TAG_DESKRIPSI, deskripsi);
                        editor.putString("email", email);
                        editor.commit();

                        //Pergi ke Activity tujuan jika berhasil
                        Intent intent = new Intent(getActivity().getApplicationContext(), GalleryActivity.class);
                        intent.putExtra(TAG_ID, id_akun);
                        intent.putExtra(TAG_USERNAME, username);
                        intent.putExtra("password", password);
                        intent.putExtra(TAG_PROFIL, ikon);
                        intent.putExtra(TAG_DESKRIPSI, deskripsi);
                        intent.putExtra(TAG_ADMIN, nama_admin);
                        intent.putExtra("email", email);
                        getActivity().finish();
                        startActivity(intent);
                    } else {
                        Toast.makeText(getContext(), jsonObject.getString(TAG_MESSAGE), Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, "Login error: "+ error.getMessage());
                Toast.makeText(getContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                hideDialog();
            }
        }){
            @Override
            protected Map<String, String>getParams(){

                Map<String, String> params = new HashMap<>();
                params.put("username", username);
                params.put("password", password);

                return params;
            }
        };
        AppController.getInstance().addToRequestQueue(stringRequest, tag_json_obj);

    }
    private void showDialog(){
        if (!progressDialog.isShowing())
            progressDialog.show();
    }
    private void hideDialog(){
        if (progressDialog.isShowing())
            progressDialog.dismiss();
    }
}


