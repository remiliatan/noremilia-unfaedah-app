package com.novalnvall.memeunfaedah.Activity;


import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.support.v4.widget.NestedScrollView;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.novalnvall.memeunfaedah.R;
import com.novalnvall.memeunfaedah.Util.Server;
import com.novalnvall.memeunfaedah.adapter.ProfilAdapter;
import com.novalnvall.memeunfaedah.fragment.Login;
import com.novalnvall.memeunfaedah.model.Gallery;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

public class MainActivity extends AppCompatActivity implements SwipeRefreshLayout.OnRefreshListener {
    private RecyclerView recyclerView;
    private SwipeRefreshLayout swipeRefreshLayout;

    private ProfilAdapter mAdapter;
    private ArrayList<Gallery> galleryArrayList;


    ImageView sam;
    LinearLayout layoutNothing;
    CircleImageView pro;
    TextView nam, des, total;

    private Button muat_ulang, ikut, diikut;
    private ConnectivityManager connectivityManager;
    private ProgressBar progressBar;
    private NestedScrollView nestedScrollView;
    private final String urlIkuti = Server.URL + "ikuti.php";

    SharedPreferences sharedPreferences;
     AdView adView;

    String nama_admin, gambar, caption, ikon, kategori, sumber, id_komentar, id, id_akun, id_pengikut;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profil);

        muat_ulang = findViewById(R.id.refresh);
        ikut = findViewById(R.id.ikuti);
        diikut = findViewById(R.id.diikuti);
        total = findViewById(R.id.total_pengikut);
        nestedScrollView = findViewById(R.id.nested);

        // Swipe refresh
        swipeRefreshLayout =  findViewById(R.id.swipe);
        swipeRefreshLayout.setColorSchemeColors(getResources().getColor(R.color.colorPrimaryDark));
        swipeRefreshLayout.setOnRefreshListener(this);

        //Progresbar
        progressBar = findViewById(R.id.progress_bar2);

        // Recycle View
        recyclerView = findViewById(R.id.recy2);

        //item Layout
        nam = findViewById(R.id.name_tv2);
        pro = findViewById(R.id.profil);
        des = findViewById(R.id.deskripsi);


        //Gambar jika tak ada kiriman
        layoutNothing = findViewById(R.id.tidak_ada);

        //Sampul
        sam = findViewById(R.id.sampul);
        Picasso.get().load(Server.URL+ "hasil/sampul.jpg").into(sam);


        sharedPreferences = getSharedPreferences(Login.my_shared_preferences, Context.MODE_PRIVATE);
        id_pengikut = sharedPreferences.getString("id_akun", "id_akun");
        Intent intent = getIntent();

        nama_admin = intent.getStringExtra("nama_admin");
        caption = intent.getStringExtra("caption");
        kategori = intent.getStringExtra("ikon");
        sumber = intent.getStringExtra("sumber");
        gambar = intent.getStringExtra("gambar");
        id_akun = intent.getStringExtra("id_akun");
        id = intent.getStringExtra("id");
        id_komentar = intent.getStringExtra("id_komentar");

        ikon = intent.getStringExtra("kategori");

        //iklan
        MobileAds.initialize(this, getResources().getString(R.string.kode_app_asli));
        adView = new AdView(this);
        adView.setAdSize(AdSize.SMART_BANNER);
        adView.setAdUnitId(getResources().getString(R.string.kode_banner_asli));
        adView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);


        // Adapter
        galleryArrayList = new ArrayList<>();
        mAdapter = new ProfilAdapter(this, galleryArrayList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(mAdapter);

        muat_ulang.setVisibility(View.GONE);

        nestedScrollView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() {
            @Override
            public void onScrollChange(NestedScrollView v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
                Display display =  getWindowManager().getDefaultDisplay();
                final int stageHeight = display.getHeight();
                int currentHeight = stageHeight + scrollY;
                int maxHeight = recyclerView.getHeight();

                if(currentHeight >= maxHeight){
                    muat_ulang.setVisibility(View.VISIBLE);
                }else {
                    muat_ulang.setVisibility(View.GONE);
                }

            }

        });

        muat_ulang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                connectivityManager = (ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
                {
                    if(connectivityManager.getActiveNetworkInfo()!=null
                            && connectivityManager.getActiveNetworkInfo().isAvailable()
                            && connectivityManager.getActiveNetworkInfo().isConnected()){
                        nestedScrollView.fullScroll(View.FOCUS_UP);
                        nestedScrollView.scrollTo(0, 0);

                        loadData(id_akun);
                        muat_ulang.setVisibility(View.GONE);
                    }else{
                        nestedScrollView.fullScroll(View.FOCUS_UP);
                        nestedScrollView.scrollTo(0, 0);

                        muat_ulang.setVisibility(View.GONE);
                        Toast.makeText(MainActivity.this, "Gagal memuat, cek koneksi internet", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });


        diikut.setVisibility(View.GONE);

        ikut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ikutiDia(id_akun, id_pengikut);
                diikut.setVisibility(View.VISIBLE);
                ikut.setVisibility(View.GONE);
            }
        });

        diikut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                janganikutiDia(id_akun, id_pengikut);
                diikut.setVisibility(View.GONE);
                ikut.setVisibility(View.VISIBLE);
            }
        });

        loadData(id_akun);




    }

    private void ikutiDia(final String id_akun, final String id_pengikut){
        StringRequest stringRequest = new StringRequest(Request.Method.POST, urlIkuti, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                Log.e("Suka: ", String.valueOf(response));
                total.setText(String.valueOf(response));
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("Error Suka", error.toString());
            }
        }){
            @Override
            protected Map<String, String>getParams(){
                Map<String, String> params = new HashMap<String, String>();
                params.put("id_pengikut", id_pengikut);
                params.put("id_akun", id_akun);
                params.put("ikuti", "ikuti");
                return  params;

            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(MainActivity.this);
        requestQueue.add(stringRequest);
    }


    private void janganikutiDia(final String id_akun, final String id_pengikut){
        StringRequest stringRequest = new StringRequest(Request.Method.POST, urlIkuti, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                Log.e("Suka: ", String.valueOf(response));
                total.setText(String.valueOf(response));
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("Error Suka", error.toString());
            }
        }){
            @Override
            protected Map<String, String>getParams(){
                Map<String, String> params = new HashMap<String, String>();
                params.put("id_pengikut", id_pengikut);
                params.put("id_akun", id_akun);
                params.put("tidak_ikuti", "ikuti");
                return  params;

            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(MainActivity.this);
        requestQueue.add(stringRequest);
    }

   private void loadData(final String id_akun){
        final String jsonUrl= Server.URL + "profil.php";

        StringRequest jsonArrayRequest =  new StringRequest(Request.Method.POST,jsonUrl, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                galleryArrayList.clear();
                    try {


                        JSONObject jsonObject1 = new JSONObject(response);
                        JSONObject object =  jsonObject1.getJSONObject("info");

                        nam.setText(object.getString("nama_admin"));
                        des.setText(object.getString("deskripsi"));
                        Picasso.get().load(Server.URL + object.getString("ikon")).into(pro);
                        total.setText(object.getString("pengikut"));

                        JSONArray pengikutArray = object.getJSONArray("banyak_pengikut");

                        for (int k = 0; k <pengikutArray.length(); k++){
                            JSONObject object1 = pengikutArray.getJSONObject(k);
                            final String id_penyuka = object1.getString("id_pengikut");
                            final String id_orang2 = object1.getString("id_akun");

                            SharedPreferences sharedPreferences1 = getSharedPreferences(Login.my_shared_preferences, Context.MODE_PRIVATE);
                            String id_orang = sharedPreferences1.getString("id_akun", "id_akun");

                            if(id_penyuka == null){
                                ikut.setVisibility(View.VISIBLE);
                                diikut.setVisibility(View.GONE);

                            }else if(id_penyuka.equals(id_orang)){
                                ikut.setVisibility(View.GONE);
                                diikut.setVisibility(View.VISIBLE);
                            }else if(id_orang2.equals(id_orang)){
                                ikut.setVisibility(View.GONE);
                                total.setText("Pengikutmu: " + object.getString("pengikut"));
                                diikut.setVisibility(View.GONE);
                            }else{
                                ikut.setVisibility(View.VISIBLE);
                                diikut.setVisibility(View.GONE);
                            }

                        }

                        JSONArray objPosting1 = jsonObject1.getJSONArray("profil");
                        JSONArray jsonMenyukai;

                        for (int i = 0; i < response.length(); i++) {
                            JSONObject jsonObject = objPosting1.getJSONObject(i);
                            Gallery gallery = new Gallery();
                            if (jsonObject == null) {
                                recyclerView.setVisibility(View.INVISIBLE);
                                layoutNothing.setVisibility(View.VISIBLE);

                            } else {
                                layoutNothing.setVisibility(View.GONE);

                                jsonMenyukai = jsonObject.getJSONArray("menyukai");

                                if (jsonMenyukai.length() > 0) {


                                    gallery.setCaption(jsonObject.getString("caption"));
                                    gallery.setNama_admin(jsonObject.getString("nama_admin"));
                                    gallery.setIkon(jsonObject.getString("ikon"));
                                    gallery.setSumber(jsonObject.getString("sumber"));
                                    gallery.setSuka(jsonObject.getString("suka"));
                                    gallery.setGambar(jsonObject.getString("gambar"));
                                    gallery.setDibuat(jsonObject.getString("tanggal_dibuat"));
                                    gallery.setKategori(jsonObject.getString("kategori"));
                                    gallery.setId(jsonObject.getString("id"));
                                    gallery.setId_akun(jsonObject.getString("id_akun"));
                                    gallery.setJumlah(jsonObject.getString("jumlah"));

                                    for (int l = 0; l < jsonMenyukai.length(); l++) {
                                        JSONObject object1 = jsonMenyukai.getJSONObject(l);
                                        gallery.setId_suka(object1.getString("id_suka"));
                                        gallery.setPenyuka(object1.getString("id_penyuka"));
                                        gallery.setIs_liked(object1.getString("id_posting"));
                                    }

                                        galleryArrayList.add(gallery);


                                } else {

                                    gallery.setCaption(jsonObject.getString("caption"));
                                    gallery.setNama_admin(jsonObject.getString("nama_admin"));
                                    gallery.setIkon(jsonObject.getString("ikon"));
                                    gallery.setSumber(jsonObject.getString("sumber"));
                                    gallery.setSuka(jsonObject.getString("suka"));
                                    gallery.setGambar(jsonObject.getString("gambar"));
                                    gallery.setDibuat(jsonObject.getString("tanggal_dibuat"));
                                    gallery.setKategori(jsonObject.getString("kategori"));
                                    gallery.setId(jsonObject.getString("id"));
                                    gallery.setId_akun(jsonObject.getString("id_akun"));
                                    gallery.setJumlah(jsonObject.getString("jumlah"));


                                        galleryArrayList.add(gallery);

                                }
                            }
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        hideProgressBar();
                    }

                mAdapter.notifyDataSetChanged();
                swipeRefreshLayout.setRefreshing(false);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("Volley", error.toString());
            }
        }){
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("id_akun", id_akun);

                return params;
            }

        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(jsonArrayRequest);

    }


    private void hideProgressBar() {
        progressBar.setVisibility(View.GONE);
    }


    @Override
    public void onRefresh() {
        loadData(id_akun);
    }
    }

