package com.novalnvall.memeunfaedah.Util;

public class Server {

    public static final String URL = "http://192.168.4.2/data/v2/";
}
