package com.novalnvall.memeunfaedah.Activity;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.novalnvall.memeunfaedah.Controller.AppController;
import com.novalnvall.memeunfaedah.R;

import com.android.volley.Request;
import com.novalnvall.memeunfaedah.Util.Server;
import com.novalnvall.memeunfaedah.fragment.Login;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

public class UpdateAkun extends AppCompatActivity {


    int success;
    public static final String TAG_ID = "id_akun";
    public static final String TAG_USERNAME = "username";
    public static final String TAG_ADMIN = "nama_admin";
    public static final String TAG_PROFIL = "ikon";
    public static final String TAG_DESKRIPSI=  "deskripsi";

    private static final String TAG_SUCCESS = "success";
    private static final String TAG_MESSAGE = "message";

    int PICK_IMAGE_REQUEST=1;
    int bitmap_size = 60;
    String tag_json_obj= "json_obj_req";
    private static final String TAG = UpdateAkun.class.getSimpleName();

    private String ikon;
    ProgressDialog progressDialog;
    ConnectivityManager connectivityManager;
    Bitmap bitmap, decoded;
    CircleImageView akunpro;
    Button  save;
    ImageView kamera;
    EditText namae, deskripsie, emaile;
    TextView gantiPassword;

    SharedPreferences sharedPreferences;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_akun);

        akunpro = findViewById(R.id.profil_up);
        kamera = findViewById(R.id.edit_profil);
        namae = findViewById(R.id.edtnama);
        deskripsie = findViewById(R.id.edtdeskripsi);
        save = findViewById(R.id.bsimpan);
        emaile = findViewById(R.id.edtemail);

        gantiPassword = findViewById(R.id.ganti);




        //Ambil status user login
        sharedPreferences = getSharedPreferences(Login.my_shared_preferences, Context.MODE_PRIVATE);
        final String id_akun = sharedPreferences.getString("id_akun", TAG_ID);

        //ambil data yang terkirim sebelumnya
        Intent dataExtra = getIntent();
        String nama_admin = dataExtra.getStringExtra(TAG_ADMIN);
        String deskripsi = dataExtra.getStringExtra(TAG_DESKRIPSI);
        String mail = dataExtra.getStringExtra("email");
        final String ikon2 = dataExtra.getStringExtra(TAG_PROFIL);


        namae.setText(nama_admin);
        deskripsie.setText(deskripsi);
        emaile.setText(mail);

        Picasso.get().load(Server.URL + ikon2).into(akunpro);

        connectivityManager = (ConnectivityManager)getSystemService(getApplicationContext().CONNECTIVITY_SERVICE);
        {
            if (connectivityManager.getActiveNetworkInfo() != null
                    && connectivityManager.getActiveNetworkInfo().isAvailable()
                    && connectivityManager.getActiveNetworkInfo().isConnected()) {
            }else{
                Toast.makeText(getApplicationContext(), "Tidak ada koneksi internet", Toast.LENGTH_SHORT).show();
            }
        }


        kamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showFileChooser();
            }
        });


        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nama_admin = namae.getText().toString();
                String deskripsi = deskripsie.getText().toString();

                final String email2 = emaile.getText().toString().trim();

                final String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

                if(nama_admin.trim().length() > 0 && deskripsi.trim().length() > 0 ) {
                    if (connectivityManager.getActiveNetworkInfo() != null
                            && connectivityManager.getActiveNetworkInfo().isAvailable()
                            && connectivityManager.getActiveNetworkInfo().isConnected()) {
                        if(email2.matches(emailPattern)){
                            checkKirim(email2, nama_admin, deskripsi,ikon2, id_akun);
                        }else {
                            Toast.makeText(UpdateAkun.this, "Format E-mail salah!", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(UpdateAkun.this, "Tidak ada koneksi internet", Toast.LENGTH_SHORT).show();
                    }
                }else {
                    Toast.makeText(UpdateAkun.this, "Masih ada yang kosong", Toast.LENGTH_SHORT).show();
                }
            }
        });

        gantiPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(UpdateAkun.this, GantiPassword.class);
                Intent bundle = getIntent();

                if(bundle != null){
                    intent.putExtras(bundle);
                }
                startActivity(intent);
            }
        });



    }
    public String getStringImage (Bitmap bmp){
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, bitmap_size,baos);
        byte[] imageBytes = baos.toByteArray();
        return Base64.encodeToString(imageBytes, Base64.DEFAULT);
    }
    private void showFileChooser(){
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
    }
    @Override
    public void onActivityResult (int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null){
            Uri filePath = data.getData();
            try{
                //Ambil dari gallery
                bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);
                setToImageView(getResizedBitmap(bitmap, 512));

            }catch (IOException e){
                e.printStackTrace();
            }
        }
    }
    private void setToImageView (Bitmap bmp){
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, bitmap_size, bytes);
        decoded = BitmapFactory.decodeStream(new ByteArrayInputStream(bytes.toByteArray()));
        akunpro.setImageBitmap(decoded);
    }
    public Bitmap getResizedBitmap (Bitmap image, int maxSize){
        int width = image.getWidth();
        int height = image.getHeight();

        float bitmapRatio = (float) width/ (float) height;
        if (bitmapRatio > 3 ){
            width = maxSize;
            height = (int) (width/bitmapRatio);
        }else{
            height = maxSize;
            width = (int) (height*bitmapRatio);
        }
        return  Bitmap.createScaledBitmap(image, width, height, true);
    }

    private void checkKirim(final String email2, final String nama_admin, final String deskripsi,final String ikon2, final String id_akun){
        progressDialog = new ProgressDialog(UpdateAkun.this);
        progressDialog.setCancelable(true);
        progressDialog.setMessage("Mengupdate info akun..");
        showDialog();

        String urlUpdate = Server.URL + "update.php";
        StringRequest stringRequest = new StringRequest(Request.Method.POST, urlUpdate, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.e(TAG, "Register Response: " + response.toString());
                hideDialog();

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    success = jsonObject.getInt(TAG_SUCCESS);
                    if (success == 1) {
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.putBoolean(Login.session_status, false);
                        editor.putString(TAG_ID, null);
                        editor.putString(TAG_USERNAME, null);
                        editor.putString(TAG_PROFIL, null);
                        editor.apply();

                        Intent intent = new Intent(UpdateAkun.this, loginregis.class);
                        startActivity(intent);
                        Toast.makeText(UpdateAkun.this, jsonObject.getString(TAG_MESSAGE), Toast.LENGTH_SHORT).show();

                    } else {
                        Toast.makeText(UpdateAkun.this, jsonObject.getString(TAG_MESSAGE), Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e (TAG,"Kirim Error: "+error.getMessage());
                Toast.makeText(UpdateAkun.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                    if(decoded == null) {
                        params.put("nama_admin", nama_admin);
                        params.put("deskripsi", deskripsi);
                        params.put("email", email2);
                        params.put("id_akun", id_akun);
                    } else {
                        params.put("nama_admin", nama_admin);
                        params.put("deskripsi", deskripsi);
                        params.put("gambar", ikon2);
                        params.put("email", email2);
                        params.put("id_akun", id_akun);
                        params.put(TAG_PROFIL, getStringImage(decoded));
                    }
                     return params;
            }
        };
        AppController.getInstance().addToRequestQueue(stringRequest, tag_json_obj);
    }
    private void showDialog(){
        if (!progressDialog.isShowing())
            progressDialog.show();
    }
    private void hideDialog(){
        if (progressDialog.isShowing())
            progressDialog.dismiss();
    }

}
