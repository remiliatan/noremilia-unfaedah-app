package com.novalnvall.memeunfaedah.Activity;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.novalnvall.memeunfaedah.Controller.AppController;
import com.novalnvall.memeunfaedah.R;
import com.novalnvall.memeunfaedah.Util.Server;
import com.novalnvall.memeunfaedah.fragment.Login;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class ActivityKiriman extends AppCompatActivity {
    private Button upload, kirimg;
    private ImageView preview;
    private EditText captionedit;
    Spinner kategorispiner;
    ProgressDialog progressDialog;

    int success;
    ConnectivityManager connectivityManager;
    Bitmap bitmap, decoded;
    private static final String TAG_SUCCESS = "success";
    private static final String TAG_MESSAGE = "message";

    int PICK_IMAGE_REQUEST=1;
    int bitmap_size = 60;
    String tag_json_obj= "json_obj_req";
    private static final String TAG = ActivityKiriman.class.getSimpleName();

    public final static String TAG_ID = "id_akun";
    public final static String TAG_GAMBAR = "gambar";

    public static final String TAG_USERNAME = "username";
    public static final String TAG_ADMIN = "nama_admin";
    public static final String TAG_PROFIL = "ikon";
    public static final String TAG_DESKRIPSI=  "deskripsi";


    SharedPreferences sharedPreferences;
    String username, nama_admin, deskripsi, ikon;
    private AdView adView;



    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kiriman);

        upload = findViewById(R.id.uploadkiriman);
        kirimg = findViewById(R.id.send);
        preview = findViewById(R.id.gambarkiriman);
        captionedit = findViewById(R.id.deskripsikamu);
        kategorispiner = findViewById(R.id.kategorispinner);



        sharedPreferences = getSharedPreferences(Login.my_shared_preferences, Context.MODE_PRIVATE);
        final String id_akun = sharedPreferences.getString("id_akun", TAG_ID);
      username = sharedPreferences.getString(TAG_USERNAME, null);
          nama_admin = sharedPreferences.getString(TAG_ADMIN, null);
         ikon = sharedPreferences.getString(TAG_PROFIL, null);
       deskripsi = sharedPreferences.getString(TAG_DESKRIPSI, null);



        //iklan
        MobileAds.initialize(this, getResources().getString(R.string.kode_app_asli));
        adView = new AdView(this);
        adView.setAdSize(AdSize.SMART_BANNER);
        adView.setAdUnitId(getResources().getString(R.string.kode_banner_asli));
        adView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);




        connectivityManager = (ConnectivityManager)getSystemService(getApplicationContext().CONNECTIVITY_SERVICE);
        {
            if (connectivityManager.getActiveNetworkInfo() != null
                    && connectivityManager.getActiveNetworkInfo().isAvailable()
                    && connectivityManager.getActiveNetworkInfo().isConnected()) {
            }else{
                Toast.makeText(getApplicationContext(), "Tidak ada koneksi internet", Toast.LENGTH_SHORT).show();
            }
        }

        upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showFileChooser();
            }
        });

        kirimg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String caption = captionedit.getText().toString();
                String kategori = kategorispiner.getSelectedItem().toString();
                String gambar = upload.getText().toString();
                @SuppressLint("SimpleDateFormat") DateFormat df = new SimpleDateFormat("EEE, d MMM yyyy HH:mm");
                String date = df.format(Calendar.getInstance().getTime());


                if(caption.trim().length() > 0 && kategori.trim().length() > 0  && gambar.trim().length() >0) {
                    if (connectivityManager.getActiveNetworkInfo() != null
                            && connectivityManager.getActiveNetworkInfo().isAvailable()
                            && connectivityManager.getActiveNetworkInfo().isConnected()) {
                        if (kategori.equals("-Pilih Kategori-")){
                            Toast.makeText(ActivityKiriman.this, "Mohon pilih kategori", Toast.LENGTH_SHORT).show();
                        }else {
                            checkKirim(date, caption, kategori, gambar, id_akun);
                        }
                    } else {
                        Toast.makeText(ActivityKiriman.this, "Tidak ada koneksi internet", Toast.LENGTH_SHORT).show();
                    }
                }else {
                    Toast.makeText(ActivityKiriman.this, "Masih ada yang kosong", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    public String getStringImage (Bitmap bmp){
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, bitmap_size,baos);
        byte[] imageBytes = baos.toByteArray();
        return Base64.encodeToString(imageBytes, Base64.DEFAULT);
    }
   private void showFileChooser(){
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
   }
   @Override
    public void onActivityResult (int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null){
            Uri filePath = data.getData();
            try{
                //Ambil dari gallery
                bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);
                setToImageView(getResizedBitmap(bitmap, 1024));

            }catch (IOException e){
                e.printStackTrace();
            }
        }
   }
   private void setToImageView (Bitmap bmp){
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, bitmap_size, bytes);
        decoded = BitmapFactory.decodeStream(new ByteArrayInputStream(bytes.toByteArray()));
        preview.setImageBitmap(decoded);
   }
   public Bitmap getResizedBitmap (Bitmap image, int maxSize){
        int width = image.getWidth();
        int height = image.getHeight();

        float bitmapRatio = (float) width/ (float) height;
        if (bitmapRatio > 3 ){
            width = maxSize;
            height = (int) (width/bitmapRatio);
        }else{
            height = maxSize;
            width = (int) (height*bitmapRatio);
        }
        return  Bitmap.createScaledBitmap(image, width, height, true);
   }
   private void checkKirim (final String date, final String caption, final String kategori, final String gambar, final String id_akun){
        progressDialog = new ProgressDialog(ActivityKiriman.this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Sedang mengirim...");
        showDialog();

       String urlKirim = Server.URL + "kirim.php";
       StringRequest stringRequest = new StringRequest(Request.Method.POST, urlKirim, new Response.Listener<String>() {
           @Override
           public void onResponse(String response) {
               Log.e(TAG, "Register Response: " + response);
               hideDialog();

               try {
                   JSONObject jsonObject = new JSONObject(response);
                   success = jsonObject.getInt(TAG_SUCCESS);
                   if (success == 1) {

                       Intent intent = new Intent(ActivityKiriman.this, GalleryActivity.class);
                       intent.putExtra(TAG_ID, id_akun);
                       intent.putExtra(TAG_USERNAME, username);
                       intent.putExtra(TAG_PROFIL, ikon);
                       intent.putExtra(TAG_DESKRIPSI, deskripsi);
                       intent.putExtra(TAG_ADMIN, nama_admin);
                       startActivity(intent);
                       Toast.makeText(ActivityKiriman.this, jsonObject.getString(TAG_MESSAGE), Toast.LENGTH_SHORT).show();
                       kosong();
                   } else {
                       Toast.makeText(ActivityKiriman.this, jsonObject.getString(TAG_MESSAGE), Toast.LENGTH_SHORT).show();
                   }
               } catch (JSONException e) {
                   e.printStackTrace();
               }
           }
       }, new Response.ErrorListener() {
           @Override
           public void onErrorResponse(VolleyError error) {
               Log.e(TAG, "Kirim error: "+error.getMessage());
               Toast.makeText(ActivityKiriman.this, error.getMessage(), Toast.LENGTH_SHORT).show();
           }
       }){
           @Override protected Map<String, String>getParams(){
               //kirim parameter ke url kiriman
               Map<String, String> params = new HashMap<String, String>();

               if (decoded == null){

                   Snackbar.make(findViewById(R.id.kirimsnack),"Harus menambah gambar", Snackbar.LENGTH_LONG).show();

               }else{
                   params.put("caption", caption);
                   params.put("kategori", kategori);
                   params.put("id_akun", id_akun);
                   params.put("tanggal_dibuat", date);
                   params.put(TAG_GAMBAR, getStringImage(decoded));
               }
               return params;

           }
       };
       AppController.getInstance().addToRequestQueue(stringRequest, tag_json_obj);
    }
    private void showDialog(){
        if (!progressDialog.isShowing())
            progressDialog.show();
    }
    private void hideDialog(){
        if (progressDialog.isShowing())
            progressDialog.dismiss();
    }
    private void kosong(){
        preview.setImageResource(0);
        captionedit.setText(null);
    }
}
