package com.novalnvall.memeunfaedah.Activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.novalnvall.memeunfaedah.Controller.AppController;
import com.novalnvall.memeunfaedah.R;
import com.novalnvall.memeunfaedah.Util.Server;
import com.novalnvall.memeunfaedah.fragment.Login;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class GantiPassword extends AppCompatActivity {

    EditText paslama, pasbaru, confirmbaru;
    Button simpan;
    ProgressDialog progressDialog;
    String  password;
    int success;

    SharedPreferences sharedPreferences;
    public static final String TAG_SUCCESS = "success";
    public static final String TAG_MESSAGE = "message";
    public static final String TAG_ID_AKUN = "id_akun";
    String tag_json_obj= "json_obj_req";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ganti_password);

        paslama = findViewById(R.id.lama);
        pasbaru = findViewById(R.id.baru);
        confirmbaru = findViewById(R.id.confirm_baru);
        simpan = findViewById(R.id.bsimpan_baru);


        sharedPreferences = getSharedPreferences(Login.my_shared_preferences, Context.MODE_PRIVATE);
        final String id_akun = sharedPreferences.getString("id_akun", TAG_ID_AKUN);

        Intent intent = getIntent();
        password = intent.getStringExtra("password");

        simpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String lama2 = paslama.getText().toString();
                String baru2 = pasbaru.getText().toString();
                String confirm = confirmbaru.getText().toString();

                if (lama2.trim().length() > 4 && baru2.trim().length() > 4 && confirm.trim().length() > 4){
                    if (!baru2.equals(confirm)) {
                        Toast.makeText(GantiPassword.this, "Password baru dan konfirmasi password harus sama", Toast.LENGTH_SHORT).show();

                    } else if (!lama2.equals(password)) {
                        Toast.makeText(GantiPassword.this, "Password lama salah", Toast.LENGTH_SHORT).show();
                    } else {
                        updatePassword(baru2, id_akun);
                    }
                }else {
                    Toast.makeText(GantiPassword.this, "Password harus lebih dari 4 huruf atau angka", Toast.LENGTH_SHORT).show();
                }
            }
        });


    }
    private void  updatePassword( final String baru2, final String id_akun){
        String urlGanti = Server.URL + "ganti_password.php";
       progressDialog = new ProgressDialog(GantiPassword.this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Mengganti password..");
        showDialog();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, urlGanti, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                hideDialog();
                try {


                    JSONObject jsonObject = new JSONObject(response);
                    success = jsonObject.getInt(TAG_SUCCESS);

                    if (success == 1) {

                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.putBoolean(Login.session_status, false);
                        editor.putString("id_akun", null);
                        editor.putString("password", null);
                        editor.putString("username", null);
                        editor.apply();

                        Intent intent = new Intent(GantiPassword.this, loginregis.class);
                        startActivity(intent);

                        Toast.makeText(GantiPassword.this, jsonObject.getString(TAG_MESSAGE), Toast.LENGTH_SHORT).show();

                    } else {
                        Toast.makeText(GantiPassword.this, "Ada kesalahan, coba lagi", Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(GantiPassword.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }){
        @Override protected Map<String, String> getParams(){
            Map<String, String> params = new HashMap<>();
            params.put("password", baru2);
            params.put("id_akun", id_akun);
            return params;
        }
        };
        AppController.getInstance().addToRequestQueue(stringRequest, tag_json_obj );
    }
    private void showDialog(){
        if (!progressDialog.isShowing())
            progressDialog.show();
    }
    private void hideDialog(){
        if (progressDialog.isShowing())
            progressDialog.dismiss();
    }

    }
