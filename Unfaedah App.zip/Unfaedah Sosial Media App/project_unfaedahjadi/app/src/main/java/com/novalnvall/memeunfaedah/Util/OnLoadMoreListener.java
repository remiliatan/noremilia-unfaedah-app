package com.novalnvall.memeunfaedah.Util;

public interface OnLoadMoreListener {
    void onLoadMore();
}
